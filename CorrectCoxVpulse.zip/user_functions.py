# -*- coding: utf-8 -*-
"""
ricardo_murphy@fastmail.fm
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import numpy as np

def ad_hoc_i(blockedfile,f,t,V,user_paras):
    """
    An ad hoc function with fixed parameters that is added to the fitted 
    functions. Used to fine tune the fit to i(t) at each V.
    blockedfile: name of the model parameter file in the blocked condition.
              f: function name as specified in the parameter file.
              t: time (ms).
              V: comamnd voltage (mV).
     user_paras: user-specified list loaded from user_parameters.txt.
        returns: current density (mA/cm^2).
    """
    return 0
    
def function_parameters(blockedfile,f,user_paras):
    """
    Parameter names for a user-specified function fitted to i(t).
    blockedfile: name of the model parameter file in the blocked condition.
              f: function name as specified in the function file (should include "#' if this is the full model).
     user_paras: user-specified list loaded from user_parameters.txt.
        returns: list of parameter names.
    """
    return []

def ini_paras(blockedfile,t,cd,f,k,V,user_paras):
    """
    Starting values for parameters in a user-specified function.
    blockedfile: name of the model parameter file in the blocked condition.
              t: numpy vector of times (ms).
             cd: numpy vector of current densities, i(t) (mA/cm^2).
              k: exponent as specified in the function file.
              V: comamnd voltage (mV).
              f: function name as specified in the function file (should include "#' if this is the full model).
     user_paras: user-specified list loaded from user_parameters.txt.
        returns: list of starting values.
    """
    return []

def it(blockedfile,p,t,f,k,V,user_paras):
    """
    User-specified functions to be fitted to i(t).
    blockedfile: name of the model parameter file in the blocked condition.
              p: list of parameter values.
              t: time (ms).
              f: function name as specified in the function file (should include "#' if this is the full model).
              k: exponent as specified in the function file.
              V: comamnd voltage (mV).
     user_paras: user-specified list loaded from user_parameters.txt.
        returns: current density (mA/cm^2).
    """
    return 0

def parameter_table(blockedfile,V,funcnames,paranames,paratable,user_paras):
    """
    Allows adjustments to the parameter estimates saved to cdn_paras.txt.
    NOTE: This function is always called, so if you don't want to make any 
    adjustments it should just return paratable unaltered.
    blockedfile: name of the model parameter file in the blocked condition.
              V: numpy vector of command voltages (mV).
      funcnames: list of function names, one for each V.
      paranames: list of parameter names for the functions fitted to i(t).
                 The length is equal to the number of parameters (np) in 
                 the full model (i.e. the fit function with the largest 
                 number of parameters).
      paratable: numpy array containg the table of parameter estimates to 
                 be saved to cdn_paras.txt. len(V) rows by np columns.
     user_paras: user-specified list loaded from user_parameters.txt.
        returns: paratable   
    """
    return paratable
