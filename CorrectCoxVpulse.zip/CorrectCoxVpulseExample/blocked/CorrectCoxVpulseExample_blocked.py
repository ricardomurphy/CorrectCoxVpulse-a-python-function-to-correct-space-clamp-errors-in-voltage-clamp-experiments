# -*- coding: utf-8 -*-
"""
ricardo_murphy@fastmail.fm
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import glob
import shutil
import CorrectCoxVpulse as cox

result = cox.CorrectCoxVpulse('blocked_parameters.txt', do_plots = 'no', saveCox = 'no') 

outputdir = result['output_folder']
shutil.copy('mossy_fiber_run_VC.hoc', outputdir+'/'+'mossy_fiber_run_VC.hoc')
shutil.copy('plot_VC_results.hoc', outputdir+'/'+'plot_VC_results.hoc')
shutil.copy('mossy_fiber_setup_VC.hoc', outputdir+'/'+'mossy_fiber_setup_VC.hoc')
shutil.copy('mossy_fiber_morphology.hoc', outputdir+'/'+'mossy_fiber_morphology.hoc')
files = glob.glob('*.mod')
for f in files:
    shutil.copy(f, outputdir+'/'+f)
shutil.copy('CorrectCoxVpulseExample_blocked.py', outputdir+'/'+'CorrectCoxVpulseExample_blocked.py')
shutil.copy('CorrectCoxVpulse.py', outputdir+'/'+'CorrectCoxVpulse.py')
shutil.copy('user_functions.py', outputdir+'/'+'user_functions.py')

