# -*- coding: utf-8 -*-
"""
ricardo_murphy@fastmail.fm
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import numpy as np

def ad_hoc_i(blockedfile,f,t,V,user_paras):
    """
    An ad hoc function with fixed parameters that is added to the fitted 
    functions. Used to fine tune the fit to i(t) at each V.
    blockedfile: name of the model parameter file in the blocked condition.
              f: function name as specified in the parameter file.
              t: time (ms).
              V: comamnd voltage (mV).
     user_paras: user-specified list loaded from user_parameters.txt.
    """
    #Of course the following data could have been loaded into user_paras 
    #from user_paramaters.txt. And you could tell whether you're dealing 
    #with control or blocked data by looking at blockedfile (which will 
    #be something other than "none" if this is control).
    if f == 'control':
        DgR = 10e-6
        ER = 50
        tauR = 100
        V0R = -60
        VmaxR = 0
    if f == 'blocked':
        DgR = 11e-5
        ER = -55
        tauR = 12
        V0R = -60
        VmaxR = 0
    if V < V0R:
        minf = 0
    elif V > VmaxR:
        minf = 1
    else:
        minf = (V - V0R)/(VmaxR - V0R)
    gR = minf*DgR*(1 - np.exp(-t/tauR))
    i = gR*(V - ER)
    return i
    
def function_parameters(blockedfile,f,user_paras):
    """
    Parameter names for a user-specified function fitted to i(t).
    blockedfile: name of the model parameter file in the blocked condition.
              f: function name as specified in the function file (should include "#' if this is the full model).
     user_paras: user-specified list loaded from user_parameters.txt.
    """
    #These are the parameter names for f = "myfunc" (see function file).
    #Of course they could have been loaded into user_paras from user_paramaters.txt.
    return ['i1inf','taum1','i2inf']

def ini_paras(blockedfile,t,cd,f,k,V,user_paras):
    """
    Starting values for parameters in a user-specified function.
    blockedfile: name of the model parameter file in the blocked condition.
              t: numpy vector of times (ms).
             cd: numpy vector of current densities, i(t) (mA/cm^2).
              k: Exponent as specified in the function file.
              V: comamnd voltage (mV).
              f: function name as specified in the function file (should include "#' if this is the full model).
     user_paras: user-specified list loaded from user_parameters.txt.
    """
    #Some of the above data might be useful in determining starting values.
    #Or you can just guess them, as here.
    return [0.05,10.0,0.05]

def it(blockedfile,p,t,f,k,V,user_paras):
    """
    User-specified functions to be fitted to i(t).
    blockedfile: name of the model parameter file in the blocked condition.
              p: list of parameter values.
              t: numpy vector of times (ms).
              f: function name as specified in the function file (should include "#' if this is the full model).
              k: Exponent as specified in the function file.
              V: comamnd voltage (mV).
     user_paras: user-specified list loaded from user_parameters.txt.
    """
    #In this case f = "myfunc". It has four parameters, but only the first 
    #three are adjustable. taum2 is fixed. Of course you could have several 
    #user-specified functions with different names.
    i1inf = p[0]; taum1 = p[1]; i2inf = p[2]; taum2 = float(user_paras[1])
    i = i1inf*(1 - np.exp(-t/taum1))**k + i2inf*(1 - np.exp(-t/taum2))
    return i

def parameter_table(blockedfile,V,funcnames,paranames,paratable,user_paras):
    """
    Allows adjustments to the parameter estimates saved to cdn_paras.txt.
    NOTE: This function is always called, so if you don't want to make any 
    adjustments it should just return paratable unaltered.
    blockedfile: name of the model parameter file in the blocked condition.
              V: numpy vector of command voltages (mV).
      funcnames: List of function names, one for each V.
      paranames: List of parameter names for the functions fitted to i(t).
                 The length is equal to the number of parameters (np) in 
                 the full model (i.e. the fit function with the largest 
                 number of parameters).
      paratable: numpy array containg the table of parameter estimates to 
                 be saved to cdn_paras.txt. len(V) rows by np columns.
     user_paras: user-specified list loaded from user_parameters.txt.
    """
    #If myfunc is fitted to i(t), which it is in control at -22 mV, 
    #set taum2 to the user-defined value in the parameter table.
    if blockedfile != 'none':  #This is the control condition.
        i = 0
        while i < len(funcnames):
            if funcnames[i] == 'myfunc': break
            i = i + 1
        j = 0
        while j < len(paranames):
            if paranames[j] == 'taum2(ms)': break
            j = j + 1
        paratable[i,j] = float(user_paras[1])
    return paratable
