# -*- coding: utf-8 -*-
"""
ricardo_murphy@fastmail.fm
Dr. Ricardo Murphy,
University of Oslo,
Domus Medica,
Division of Physiology,
Pb. 1103, Blindern,
0317 Oslo
Norway
"""

import sys
import os
import time
import glob
import shutil
import subprocess as sb
import numpy as np
from scipy import optimize as op
from scipy import integrate as ode
from scipy import interpolate as intp
import matplotlib.pyplot as plt
import user_functions as uf

import rpy2
import rpy2.robjects as robjects
from rpy2.robjects.packages import importr
# import R's "base" package
base = importr('base')
# import R's "utils" package
utils = importr('utils')
# import R's "stats" package
utils = importr('stats')
smooth_spline = robjects.r['smooth.spline']
predict = robjects.r['predict']


def fit_no_error(p,pn,t,I,nv,n,tbreak,parameter_file,neuron_file,neuron_path,fmt,w):
    file = open('parameter_file.txt','r')
    l = file.readlines(); file.close()
    s = l[1].split(); it = int(s[1]) + 1
    file = open('parameter_file.txt','w')
    file.write(parameter_file+'\n')
    file.write('No_space-clamp_errors: %d'%it+'\n')
    i = 0
    while i < len(p):
        file.write('%s'%pn[i]+': '+fmt%p[i]+'\n')
        i = i + 1
    file.close()         
    delete_file('flag.txt'); flag = ''
    if len(neuron_path) == 0:
        sb.run('neuron.exe '+neuron_file)
    else:
        sb.run(neuron_path+'/neuron.exe '+neuron_file)
    while len(flag) == 0:
        try:
            file = open('flag.txt','r')
            data = file.readlines()
            flag = data[0]
            file.close()
        except (FileNotFoundError,IndexError):
            pass
    tp,predI0 = load_tVI('tDIpred.txt')
    tp,predI0 = extract(tp,predI0,tbreak);
    predI = np.zeros(n)
    resids = np.zeros(nv*n)
    sse = 0; j = 0
    while j < nv:
        pp = intp.interp1d(tp,predI0[:,j],fill_value='extrapolate')
        predI = pp(t); i = 0
        while i < n:
            ij = j*n + i
            resids[ij] = I[i,j] - predI[i]
            if len(w) > 0: 
                resids[ij] = w[j]*resids[ij]
            else:
                resids[ij] = resids[ij]*1e-3
            sse = sse + resids[ij]*resids[ij]
            i = i + 1
        j = j + 1
    
    print(); i = 0
    print('Iteration: %d'%it)
    while i < len(pn):
        print('%s'%pn[i]+' = '+fmt%p[i])
        i = i + 1
    if len(w) == 0:
        print('SSE (nA^2) = %g'%sse)
    else:
        print('Weighted SSE = %g'%sse)
    resids = resids.astype(dtype=np.float32)
    return resids
    
def fit_neuron(parameter_file = '', p = {}, fmt = '%15.5e', weighted_fit = 'yes', pv = [], 
        jac='3-point', bounds=(-np.inf, np.inf), method='trf', ftol=1e-08, xtol=1e-08, 
        gtol=1e-08, x_scale=1.0, loss='linear', f_scale=1.0, diff_step=None, 
        tr_solver=None, tr_options={}, jac_sparsity=None, max_nfev=None, verbose=0):
    p0 = np.array(list(p.values())); pn = list(p.keys())
    plt.close('all'); plt.ion
    neuron_path = ''; cwd = os.getcwd()
    if parameter_file == '': 
        file = open('parameter_file.txt','r')
        data = file.readlines(); file.close()
        parameter_file = data[0].strip('\n')
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    tbreak = [0,0,0]; i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        v[1] = v[1].strip()
        if len(v) > 2:
            j = 2
            while j < len(v):
                v[1] = v[1] + ':'+v[j]
                j = j + 1
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'neuron_path': neuron_path  = v[1]
            if v[0] == 'neuron_file': neuron_file = v[1]
            if v[0] == 'Iunit': Iunit = v[1]
            if v[0] == 'tunit': tunit = v[1]
            if v[0] == 'Data_delimeter': 
                delim = v[1]
                if delim == 'tab': delim = '\t'
                if delim == 'space': delim = ''
            if v[0] == 'Decimate_data_by_a_factor_of': 
                if len(v) > 1:
                    v = v[1].split()
                    dec = []; j = 0
                    while j < len(v):
                        dec.append(float(v[j]))
                        if dec[j] > 0 and dec[j] < 1: dec[j] = 1/dec[j]
                        dec[j] = int(dec[j])
                        j = j + 1
                else:
                    dec = []
            if v[0] == 'Fraction_of_trace_for_estimating_SD(I)': frac = float(v[1])
            if v[0] == 'Number_of_header_lines_to_skip_(excluding_column_names)': skip = int(v[1])
            if v[0] == 'Leak-subtracted_currents_in_file': controlfile = v[1]
            if v[0] == 'Model_parameter_file_for_blocked_condition': rescdfile = v[1]
            if v[0] == 'outputdir': outputdir = v[1]
            if v[0] == 'tstart(ms)': tbreak[1] = float(v[1])
            if v[0] == 'tstop(ms)': tbreak[2] = float(v[1])
            if v[0] == 'Vcmnd(mV)': 
                v = v[1].split()
                Vcmnd = []; j = 0
                while j < len(v):
                    Vcmnd.append(float(v[j]))
                    j = j + 1
        i = i + 1
    
    V = np.array(Vcmnd); nv = len(V)
    if 'Raw_tDI.txt' in controlfile:
        t,I = load_tVI(controlfile); I = np.delete(I,0,axis=1)
    else:
        t,I = load_tVI(controlfile,skip=skip,delim=delim)
        if Iunit != 'pA': I = 1000*I  #nA -> pA
        if tunit != 'ms': t = 1000*t  #s -> ms
        t,I = extract(t,I,tbreak)
        if len(dec) > 0: t,I = decimate(t,I,dec)
    try:
        os.chdir(outputdir)
        os.chdir(cwd)
        shutil.rmtree(outputdir, ignore_errors=True)
        os.rmdir(outputdir)
        os.mkdir(outputdir)
    except FileNotFoundError:
        os.mkdir(outputdir)
    os.chdir(cwd)
    print('\r')
    
    file = open('parameter_file.txt','w')
    file.write(parameter_file+'\n')
    file.write('No_space-clamp_errors: 0\n')
    file.close()
    if weighted_fit == 'yes':
        sdI = SDI(V,t,I,frac,0); w = 1/sdI[0]
    else:
        w = []
    n = len(t); p0 = p0.astype(dtype=np.float32);
    if len(p0) > 1 or len(pv) == 0:
        res = op.least_squares(fit_no_error, p0, 
                jac=jac, bounds=bounds, method=method, ftol=ftol, xtol=xtol, verbose=verbose, 
                gtol=gtol, x_scale=x_scale, loss=loss, f_scale=f_scale, diff_step=diff_step, 
                tr_solver=tr_solver, tr_options=tr_options, jac_sparsity=jac_sparsity, max_nfev=max_nfev, 
                args = (pn,t,I,nv,n,tbreak,parameter_file,neuron_file,neuron_path,fmt,w))
        tp,predI = load_tVI('tDIpred.txt')    
        t = t + tbreak[1]; kk = 0
        fig = plt.figure(1); ax = fig.add_subplot(111)
        while kk < nv:
            plt.plot(t,I[:,kk],linewidth=0.5,color='0.6')
            plt.plot(tp,predI[:,kk],'k-',linewidth=1.0)
            kk = kk + 1
        plt.xlabel('$t$ (ms)')
        plt.ylabel('$I$ (pA)')
        legend = ['Observed $I$','Predicted $I$']
        plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
        plt.title('Leak-subtracted currents predicted by the model')
        plt.savefig(outputdir+'/I.png',dpi=600)
        
        file = open('parameter_file.txt','r')
        l = file.readlines(); file.close()
        s = l[1].split(); it = int(s[1])
        file = open('parameter_file.txt','w')
        file.write(parameter_file+'\n')
        file.write('No_space-clamp_errors: %d'%it+'\n')
        i = 0
        while i < len(pn):
            file.write('%s'%pn[i]+': '+fmt%res.x[i]+'\n')
            i = i + 1
        if weighted_fit == 'yes':
            file.write('Weighted SSE: %g'%(2*res.cost)+'\n')
        else:
            file.write('SSE(nA^2): %g'%(2*res.cost)+'\n')
        file.close()
        print(res.message)
        
        shutil.copy('tDIpred.txt', outputdir+'/')
        shutil.copy('parameter_file.txt', outputdir+'/fit_neuron.txt')
        shutil.copy(controlfile, outputdir+'/')
        shutil.copy(parameter_file, outputdir+'/')
        result = {}
        result['output_folder'] = outputdir
        result['Residuals(pA)'] =  res.fun
        result['least_squares_output'] =  res
        return result
    else:
        file = open(pn[0]+'_SSE.txt','w')
        file.write('%3s'%'#'+'%15s'%pn[0]+'%15s'%'SSE'+'\n')
        if pv[1] > 1:
            dp = (pv[0] - p0[0])/(pv[1]-1)
        else:
            dp = 0
        i = 0
        while i < pv[1]:
            pval = np.array([p0[0] + i*dp])
            res = fit_no_error(pval,pn,t,I,nv,n,tbreak,parameter_file,neuron_file,neuron_path,fmt,w)
            res_sq = res*res; sse = np.sum(res_sq)
            file.write('%3d'%(i+1)+'%15.5e'%pval+'%15.5e'%sse+'\n')
            i = i + 1
        file.close()
        return {}

def no_space_clamp_errors(parameter_file = '', print_paras = 'yes', taum_mult = 5.0):
    plt.close('all'); plt.ion; user_paras = []; cwd = os.getcwd()
    try:
        file = open('user_parameters.txt','r')
        user_paras = file.readlines(); file.close()
    except (FileNotFoundError,IndexError):
        pass
    if parameter_file == '': 
        file = open('parameter_file.txt','r')
        data = file.readlines(); file.close()
        parameter_file = data[0].strip('\n')
    file = open(parameter_file,'r')
    data = file.readlines(); file.close(); plt.close('all')
    tbreak = [0,0,0]; i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        v[1] = v[1].strip()
        if len(v) > 2:
            j = 2
            while j < len(v):
                v[1] = v[1] + ':'+v[j]
                j = j + 1
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'Iunit': Iunit = v[1]
            if v[0] == 'tunit': tunit = v[1]
            if v[0] == 'Data_delimeter': 
                delim = v[1]
                if delim == 'tab': delim = '\t'
                if delim == 'space': delim = ''
            if v[0] == 'Decimate_data_by_a_factor_of': 
                if len(v) > 1:
                    v = v[1].split()
                    dec = []; j = 0
                    while j < len(v):
                        dec.append(float(v[j]))
                        if dec[j] > 0 and dec[j] < 1: dec[j] = 1/dec[j]
                        dec[j] = int(dec[j])
                        j = j + 1
                else:
                    dec = []
            if v[0] == 'Number_of_header_lines_to_skip_(excluding_column_names)': skip = int(v[1])
            if v[0] == 'Leak-subtracted_currents_in_file': controlfile = v[1]
            if v[0] == 'Subtract_from_I(t,V)_the_currents_in_file': rescdfile = v[1]
            if v[0] == 'Fit_functions_for_i(t,V)_in_file': funcfile = v[1]
            if v[0] == 'Add_this_ad_hoc_function_to_i(t,V)': adhocfunc = v[1]
            if v[0] == 'outputdir': outputdir = v[1]
            if v[0] == 'Area(um^2)': A = float(v[1])
            if v[0] == 'Vhold(mV)': Vhold = float(v[1])
            if v[0] == 'tstart(ms)': tbreak[1] = float(v[1])
            if v[0] == 'tstop(ms)': tbreak[2] = float(v[1])
            if v[0] == 'Vcmnd(mV)': 
                v = v[1].split()
                Vcmnd = []; j = 0
                while j < len(v):
                    Vcmnd.append(float(v[j]))
                    j = j + 1
            if v[0] == 'V_LJP_corrected': V_LJP_corrected = v[1]
            if v[0] == 'LJP(mV)': LJP = float(v[1])
        i = i + 1
    
    V = np.array(Vcmnd)
    V = np.insert(V,0,Vhold,axis=0)
    if V_LJP_corrected == 'no': V = V - LJP
    nv = len(V)
    if 'Raw_tDI.txt' in controlfile:
        t,I = load_tVI(controlfile)
    else:
        t,I = load_tVI(controlfile,skip=skip,delim=delim)
        if Iunit != 'pA': I = 1000*I  #nA -> pA
        if tunit != 'ms': t = 1000*t  #s -> ms
        t,I = extract(t,I,tbreak); I = np.insert(I,0,0,axis=1)
        if len(dec) > 0: t,I = decimate(t,I,dec)
    if rescdfile != 'none':
        tb,Ib = load_tVI(rescdfile,skip=skip,delim=delim)
        if Iunit != 'pA': Ib = 1000*I  #nA -> pA
        if tunit != 'ms': tb = 1000*t  #s -> ms
        tb,Ib = extract(tb,Ib,tbreak); Ib = np.insert(Ib,0,0,axis=1)
        if len(dec) > 0: tb,Ib = decimate(tb,Ib,dec)
        cd = 0.1*(I - Ib)/A  #pA -> mA/cm^2
    else:
        cd = 0.1*I/A  #pA -> mA/cm^2
    file = open('parameter_file.txt','w')
    file.write(parameter_file+'\n')
    file.write('No_space-clamp_errors: 0\n')
    file.close() 
    try:
        os.chdir(outputdir)
        os.chdir(cwd)
        shutil.rmtree(outputdir, ignore_errors=True)
        os.rmdir(outputdir)
        os.mkdir(outputdir)
    except FileNotFoundError:
        os.mkdir(outputdir)
    os.chdir(cwd)
    print('\r')
    
    f = open(funcfile, 'r'); l = f.readlines(); file.close()
    i = 0
    while i < len(l):
        if 'func.' in l[i]: break
        l[i] = l[i].strip('\n')
        v = l[i].split(':')
        if len(v) > 1:
            v[1] = v[1].strip()
            if v[0]  == 'k': power = int(v[1])
            if v[0]  == 'Erev(mV)': Erev = float(v[1])
            if 'taum1_extrapolation_(low_V)' in v[0]: taum1_extrap_low = v[1]
            if 'taum1_low_V_(ms)' in v[0]: taum1_low_V = float(v[1])
            if 'taum1_extrapolation_(high_V)' in v[0]: taum1_extrap_high = v[1]
            if 'taum1_high_V_(ms)' in v[0]: taum1_high_V = float(v[1])
            if 'taum2_extrapolation_(low_V)' in v[0]: taum2_extrap_low = v[1]
            if 'taum2_low_V_(ms)' in v[0]: taum2_low_V = float(v[1])
            if 'taum2_extrapolation_(high_V)' in v[0]: taum2_extrap_high = v[1]
            if 'taum2_high_V_(ms)' in v[0]: taum2_high_V = float(v[1])
            if 'taum3_extrapolation_(low_V)' in v[0]: taum3_extrap_low = v[1]
            if 'taum3_low_V_(ms)' in v[0]: taum3_low_V = float(v[1])
            if 'taum3_extrapolation_(high_V)' in v[0]: taum3_extrap_high = v[1]
            if 'taum3_high_V_(ms)' in v[0]: taum3_high_V = float(v[1])
            if 'tauh1_extrapolation_(low_V)' in v[0]: tauh1_extrap_low = v[1]
            if 'tauh1_low_V_(ms)' in v[0]: tauh1_low_V = float(v[1])
            if 'tauh1_extrapolation_(high_V)' in v[0]: tauh1_extrap_high = v[1]
            if 'tauh1_high_V_(ms)' in v[0]: tauh1_high_V = float(v[1])
            if 'tauh2_extrapolation_(low_V)' in v[0]: tauh2_extrap_low = v[1]
            if 'tauh2_low_V_(ms)' in v[0]: tauh2_low_V = float(v[1])
            if 'tauh2_extrapolation_(high_V)' in v[0]: tauh2_extrap_high = v[1]
            if 'tauh2_high_V_(ms)' in v[0]: tauh2_high_V = float(v[1])
        i = i + 1
    i = i + 1
    func = ['0']; func_paras = ['']; 
    paran = [[]]; parav = [[]]; ij = 0
    while i < len(l):
        if len(l[i]) > 1:
            paran.append([]); parav.append([])
            ij = ij + 1
            l[i] = l[i].strip('\n')
            v = l[i].split()
            func.append(v[1])
            func_paras.append(function_parameters(rescdfile,v[1],user_paras))
            if len(v) > 2:
                j = 2
                while j < len(v):
                    paran[ij].append(v[j])
                    parav[ij].append(float(v[j+1]))
                    j = j + 2
        i = i + 1
    npmax = len(func_paras[0])
    fullmodel = func[0]; i = 1
    while i < len(func_paras):
        if len(func_paras[i]) > npmax: 
            npmax = len(func_paras[i])
            fullmodel = func[i]
        i = i + 1
    if fullmodel == '0+A' or fullmodel == 'A^k+L': fullmodel = 'A^k+A'
    if fullmodel == '0+A+L': fullmodel = 'A^k+A+L'
        
    taumb = taum_mult*t[len(t)-1]
    if '#' not in fullmodel:
        if fullmodel == 'A^k': 
            paratable = np.zeros([nv,2])
            paranames = ['i1inf(mA/cm2)','taum1(ms)']
        elif fullmodel == 'A^k+A' or fullmodel == '0+A' or fullmodel == 'A^k+L': 
            paratable = np.zeros([nv,4])
            paranames = ['i1inf(mA/cm2)','taum1(ms)','i2inf(mA/cm2)','taum2(ms)']
            if 'L' in fullmodel:
                taumb = taum_mult*t[len(t)-1]; i = 0
                while i < nv:                          
                    paratable[i,3] = taumb
                    i = i + 1
        elif fullmodel == '(A^k)A': 
            paratable = np.zeros([nv,3])
            paranames = ['i1inf(mA/cm2)','taum1a(ms)','taum1b(ms)']
        elif fullmodel == '(A^k)A+L': 
            paratable = np.zeros([nv,5])
            paranames = ['i1inf(mA/cm2)','taum1a(ms)','taum1b(ms)','i2inf(mA/cm2)','taum2(ms)']
            taumb = taum_mult*t[len(t)-1]; i = 0
            while i < nv:  
                if 'L' in func[i]: paratable[i,4] = taumb
                i = i + 1
        elif fullmodel == 'A^k+A+L'or fullmodel == '0+A+L': 
            paratable = np.zeros([nv,6])
            paranames = ['i1inf(mA/cm2)','taum1(ms)','i2inf(mA/cm2)','taum2(ms)','i3inf(mA/cm2)','taum3(ms)']
            taumb = taum_mult*t[len(t)-1]; i = 0
            while i < nv:                          
                if 'L' in func[i]: paratable[i,5] = taumb
                i = i + 1
        elif fullmodel == '(A^k)Ia' or fullmodel == '(A^k)Ib' or fullmodel == '(A^k)Ic': 
            paratable = np.zeros([nv,4]); i = 0
            while i < nv:
                if 'a' in func[i] or 'b' in func[i]:
                    paratable[i,3] = 0
                else:
                    paratable[i,3] = 1
                i = i + 1
            paranames = ['i1inf(mA/cm2)','taum1(ms)','tauh1(ms)','h1inf']
        elif '(A^k)II' in fullmodel:
            paratable = np.zeros([nv,6]); i = 0
            while i < nv:
                if 'd' in func[i] or 'e' in func[i]:
                    paratable[i,5] = 0
                else:
                    paratable[i,5] = 1
                if 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                    paratable[i,3] = 0
                else:
                    paratable[i,3] = 1
                i = i + 1
            paranames = ['i1inf(mA/cm2)','taum1(ms)','tauh1(ms)','h1inf','tauh2(ms)','h2inf']
    else:
        paranames = uf.function_parameters(rescdfile,fullmodel,user_paras)
        paratable = np.zeros([nv,len(paranames)])

    cdfunc = np.zeros([1000,nv]); tfunc = np.zeros(1000)
    n = len(t); Dt = t[n-1]-t[0]; dt = Dt/999; i = 0
    while i < 1000:
        tfunc[i] = i*dt
        i = i + 1
    i = 0
    while i < nv:
        p0 = ini_paras(rescdfile,t,cd[:,i],func[i],power,V[i],adhocfunc,user_paras)
        if len(p0) > 0:
            if len(paran[i]) > 0:
                kk = 0
                while kk < len(paran[i]):
                    jk = func_paras[i].index(paran[i][kk])
                    p0[jk] = parav[i][kk]
                    kk = kk + 1
            print('')
            print(V[i],' mV')
            if print_paras == 'yes': print('Initial parameter estimates: ',p0)                    
            try:
                res = op.least_squares(iresids, p0, args = (rescdfile,t,cd[:,i],func[i],power,V[i],adhocfunc,user_paras))
            except:
                print('')
                print('Problem with fiting at V = '+'%5.1f'%Vcmnd[i-1]+' mV\r')
                print('Initial parameter estimates: ',p0)
                print('Plotting the offending current density and exiting.')
                print('')
                fig = plt.figure()
                plt.plot(t,cd[:,i],linewidth=1.0,color='b')
                plt.xlabel('$t$ (ms)')
                plt.ylabel('$i$ (mA cm$^{\minus2}$)')
                plt.title('Problem with fiting at V = '+'%5.1f'%V[i]+' mV')
                break
            p = res.x; j = 0
            if print_paras == 'yes': print('Final parameter estimates: ',p)
            while j < 1000:
                cdfunc[j,i] = it(rescdfile,p,tfunc[j],func[i],power,V[i],adhocfunc,user_paras)
                j = j + 1
            nparas = len(func_paras[i]); j = 0
            while j < nparas:
                if 'L' in func[i] and '0+' not in func[i] and func_paras[i][j] == 'b':
                    paratable[i,j] = p[j]*taumb   #i2inf
                    paratable[i,j+1] = taumb
                elif '0+' in func[i]:
                    if 'L' in func[i] and func_paras[i][j] == 'b':
                        paratable[i,j+2] = p[j]*taumb
                        paratable[i,j+3] = taumb
                    else:
                        paratable[i,j+2] = p[j]
                    if j < 2: paratable[i,j] = 0
                elif 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                    if j > 2: 
                        paratable[i,j+1] = p[j]
                    else:
                        paratable[i,j] = p[j]
                else:
                    paratable[i,j] = p[j]
                if 'I' in func[i] and func_paras[i][j] == 'b':
                    if 'Ib' in func[i]:
                        paratable[i,j] = 1/p[j]   #tauh
                    else:
                        paratable[i,j+1] = 1/p[j]   #tauh
                j = j + 1
            if func[i] == '(A^k)Ia' or func[i] == '(A^k)Ib' or 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                paratable[i,3] = 0
            if func[i] == '(A^k)IIa' or func[i] == '(A^k)IIb' or 'd' in func[i] or 'e' in func[i]:
                paratable[i,5] = 0 
        else:
            cdfunc[:,i] = 0
        i = i + 1
    
        if 'I' not in fullmodel:
            paratable[:,1] = impute_tau(fullmodel,V,paratable[:,1],taum1_extrap_low,taum1_low_V,taum1_extrap_high,taum1_high_V)
            if 'A^k+A' in fullmodel:
                paratable[:,3] = impute_tau(fullmodel,V,paratable[:,3],taum2_extrap_low,taum2_low_V,taum2_extrap_high,taum2_high_V)
                if 'L' in fullmodel:
                    paratable[:,5] = impute_tau(fullmodel,V,paratable[:,5],taum3_extrap_low,taum3_low_V,taum3_extrap_high,taum3_high_V)
            if '(A^k)A' in fullmodel:
                paratable[:,2] = impute_tau(fullmodel,V,paratable[:,2],taum2_extrap_low,taum2_low_V,taum2_extrap_high,taum2_high_V)
                if 'L' in fullmodel:
                    paratable[:,4] = impute_tau(fullmodel,V,paratable[:,4],taum3_extrap_low,taum3_low_V,taum3_extrap_high,taum3_high_V)
        else:
            paratable[:,1] = impute_tau(fullmodel,V,paratable[:,1],taum1_extrap_low,taum1_low_V,taum1_extrap_high,taum1_high_V)
            paratable[:,2] = impute_tau(fullmodel,V,paratable[:,2],tauh1_extrap_low,tauh1_low_V,tauh1_extrap_high,tauh1_high_V)
            if 'tauh2(ms)' in paranames:
                paratable[:,4] = impute_tau(fullmodel,V,paratable[:,4],tauh2_extrap_low,tauh2_low_V,tauh2_extrap_high,tauh2_high_V)
        paratable = uf.parameter_table(rescdfile,V,func,paranames,paratable,user_paras)
    
    file = open('cdn_paras.txt','w')
    file.write(fullmodel+'  k = '+str(power)+'  Erev(mV) = '+str(Erev)+'\n')
    file.write('%8s'%'V(mV)'); i = 0
    while i < len(paranames):
        file.write('%15s'%paranames[i])
        i = i + 1
    file.write('\n')
    i = 0
    while i < nv:
        file.write('%8.1f'%V[i])
        j = 0
        while j < len(paranames):
            file.write('%15e'%paratable[i,j])
            j = j + 1
        file.write('\n')
        i = i + 1
    file.close()
    shutil.copy('cdn_paras.txt', outputdir+'/cdn_paras.txt')
    
    kk = 0
    while kk < nv:
        if kk == 0:
            fig = plt.figure()
        plt.plot(t,cd[:,kk],linewidth=0.5,color='b')
        plt.plot(tfunc,cdfunc[:,kk],'k-',linewidth=1.0)
        kk = kk + 1
    plt.xlabel('$t$ (ms)')
    plt.ylabel('$i$ (mA cm$^{\minus2}$)')
    plt.title('No correction for space-clamp errors')
    plt.savefig(outputdir+'/cd_fit.png',dpi=600)    
    cdfunc = np.delete(cdfunc,0,1)
    save_tVI('cd_fit.txt',tfunc,Vcmnd,cdfunc,'i(mA/cm^2)')
    shutil.copy('cd_fit.txt', outputdir+'/cd_fit.txt')
    cd = np.delete(cd,0,1)
    save_tVI('cd.txt',t,Vcmnd,cd,'i(mA/cm^2)')
    shutil.copy('cd.txt', outputdir+'/cd.txt')
    
    logtauh = 0
    if 'II' in fullmodel:
        tauh1max = np.max(paratable[:,2])
        tauh2max = np.max(paratable[:,4])
        if tauh1max > 0 and tauh2max > 0:
            if tauh1max/tauh2max < 0.1: logtauh = 1
            if tauh1max/tauh2max > 10: logtauh = 1
    if fullmodel == 'A^k':
        fig, axs = plt.subplots(2, 1, sharex='all')
        axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
        axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
        axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
        axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
        axs[1].set_xlabel('$V$ (mV)')
        axs[1].set_ylabel('${\\tau}m1$ (ms)')
    elif '(A^k)A' in fullmodel:
        fig, axs = plt.subplots(2, 1, sharex='all')
        axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
        axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
        axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
        axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
        axs[1].plot(V,paratable[:,2],'b-o',linewidth=1.0)
        axs[1].legend(['${\\tau}m1a$','${\\tau}m1b$'], title='ms', fontsize=10)                        
        axs[1].set_xlabel('$V$ (mV)')
        axs[1].set_ylabel('${\\tau}m$ (ms)')
    elif 'A^k+' in fullmodel: 
        fig, axs = plt.subplots(2, 2, sharex='all')
        axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
        axs[0,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
        axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
        axs[1,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
        axs[1,0].set_xlabel('$V$ (mV)')
        axs[1,1].set_xlabel('$V$ (mV)')
        axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
        axs[0,1].legend(['$i2\infty$','$i$L'],title = 'mA cm$^{\minus2}$')
        axs[1,0].legend(['${\\tau}m1$','$i$L'],title = 'ms')                
        axs[1,1].legend(['${\\tau}m2$','$i$L'],title = 'ms')                
    else:
        fig, axs = plt.subplots(2, 2, sharex='all')
        axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
        axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
        axs[0,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
        if logtauh == 1:
            axs[1,1].semilogy(V,paratable[:,2],'k-o',linewidth=1.0)
        else:
            axs[1,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
        axs[1,0].set_xlabel('$V$ (mV)')
        axs[1,1].set_xlabel('$V$ (mV)')
        axs[1,0].legend(['${\\tau}m1$'],title = 'ms')
        axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')
        if 'II' not in fullmodel:
            axs[0,1].legend(['$h1\infty$'], fontsize=10) 
            axs[1,1].legend(['${\\tau}h1$'], title='ms', fontsize=10) 
        else:
            axs[0,1].plot(V,paratable[:,5],'b-o',linewidth=1.0)
            axs[0,1].legend(['$h1$','$h2$'], title='$h\infty$', fontsize=10)                        
            if logtauh == 1:
                axs[1,1].semilogy(V,paratable[:,4],'b-o',linewidth=1.0)
            else:
                axs[1,1].plot(V,paratable[:,4],'b-o',linewidth=1.0)
            axs[1,1].legend(['$h1$','$h2$'], title='${\\tau}h$ (ms)', fontsize=10)
    fig.suptitle('No correction for space-clamp errors')
    plt.savefig(outputdir+'/cdn_paras.png',dpi=600)
    
    if rescdfile != 'none': shutil.copy(rescdfile, outputdir+'/')
    shutil.copy(controlfile, outputdir+'/')
    shutil.copy(funcfile, outputdir+'/')
    shutil.copy(parameter_file, outputdir+'/')
    result = {}
    result['output_folder'] = outputdir
    return result

def get_filenames(dir='', temp='', rec=False):
    files = []
    if len(dir) > 0:
        files = glob.glob(dir+'\\'+temp, recursive=rec)
    else:
        files = glob.glob(temp)
    return files

def delete_file(fn):
    file = glob.glob(fn)
    if len(file) > 0: os.remove(file[0])

def load_matrix(fn,skip=0,delim=''):
    file = open(fn,'r'); data = file.readlines()
    file.close(); S = []; nd = 0; i = 0
    if skip > 0:
        i = 0
        while i < skip:
            S.append(data[i])
            i = i + 1
    if len(delim) == 0:
        H = data[skip].split(); m = len(H)
        n = len(data)-skip-1; M = np.zeros([n,m]); i = 0
        while i < n:
            v = data[i+skip+1].split()
            if len(v) == m:
                nd = nd + 1; j = 0
                while j < m:
                    M[i,j] = float(v[j])
                    j = j + 1
            i = i + 1
    else:
        H = data[skip].split(delim); m = len(H)
        n = len(data)-skip-1; M = np.zeros([n,m]); i = 0
        while i < n:
            v = data[i+skip+1].split(delim)
            if len(v) == m:
                nd = nd + 1; j = 0
                while j < m:
                    M[i,j] = float(v[j])
                    j = j + 1
            i = i + 1
    if nd < n: M = np.delete(M,np.s_[nd:n],0)
    return M,H,S

def load_tVI(fn,skip=0,delim=''):
    M = load_matrix(fn,skip=skip,delim=delim)
    t = M[0][:,0]; t = t - t[0]
    M = np.delete(M[0],0,1)
    return t,M
    
def decimate(t,M,d):
    j = 0; td = []; m = len(d)
    while j < m:
        td.append((j+1)*t[len(t)-1]/m)
        j = j + 1
    i = 0; j = 0
    while i < len(t):
        if t[i] > td[j]: j = j + 1
        i1 = i + 1; i2 = i1 + d[j] - 1; 
        t = np.delete(t,np.s_[i1:i2],0)
        M = np.delete(M,np.s_[i1:i2],0)
        i = i + 1
    return t,M
    
def extract(t,M,tbreak):    
    if len(tbreak) > 0:
        i = 0; i1 = 0
        while i < len(t) and i1 == 0:
            if t[i] >= tbreak[1]: i1 = i
            i = i + 1
        ii = np.arange(0,i1)
        t = np.delete(t,ii,0)
        M = np.delete(M,ii,0) 
        i = len(t)-1; i2 = 0
        while i > -1 and i2 == 0:
            if t[i] <= tbreak[2]: i2 = i+1
            i = i - 1
        ii = np.arange(i2,len(t))
        t = np.delete(t,ii,0)
        M = np.delete(M,ii,0) 
        t = t - tbreak[1]; 
    return t,M
    
def load_xyz(fn,xc,yc,zc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    y = np.zeros(n); z = np.zeros(n)
    i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        y[i] = float(v[yc])
        z[i] = float(v[zc])
        i = i + 1
    return x,y,z
        
def load_xy(fn,xc,yc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    y = np.zeros(n); i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        y[i] = float(v[yc])
        i = i + 1        
    return x,y
    
def load_x(fn,xc):
    file = open(fn,'r')
    data = file.readlines(); file.close()
    n = len(data)-1; x = np.zeros(n)
    i = 0
    while i < n:
        v = data[i+1].split()
        x[i] = float(v[xc])
        i = i + 1        
    return x    

def save_tVI(fn,t,V,y,yn='I(pA)'): 
    yn = '_'+yn; file = open(fn,'w')
    file.write('%10s'%'t(ms)')
    nv = len(V); j = 0
    while j < nv:
        file.write('%17s'%('%7.1f'%V[j]+yn))
        j = j + 1
    file.write('\r')
    n = len(t); i = 0
    while i < n:
        file.write('%10.3f'%t[i])
        j = 0
        while j < nv:
            file.write('%17e'%y[i,j])
            j = j + 1
        file.write('\r')
        i = i + 1
    file.close()    

def getVrest(m,p,V1,V2):
    if m > 0:
        V = np.roots(p)
    else:
        V = p.roots()
    Vr = np.isreal(V)
    Vrest = []; i = 0
    while i < len(Vr):
        realV = np.real(V[i])
        if Vr[i] == True and realV >= V1 and realV <= V2: 
            Vrest.append(realV)
        i = i + 1
    return Vrest
    
def EstimateVrest(i,j,poly,p,V0,Vrest,DV=0.1):
    if i == 0: poly = [1]
    m = len(poly)
    if (m == 1 or m == 2) and isinstance(poly[0], int):
        b = dpoly(p,V0)
    elif m == 0:
        b = dlinterp(p,V0,DV)
    else:
        bp = p.derivative(); b = bp(V0)
    if b != 0:
        if (m == 1 or m == 2) and isinstance(poly[0], int):
            a = np.polyval(p,V0)
        else:
            a  = p(V0)
        Vrest0 = V0 - a/b
        if j == 1 and Vrest0 < V0: Vrest.append(Vrest0)
        if j == 2 and Vrest0 > V0: Vrest.append(Vrest0)
    return Vrest

def linterpol(x1,y1,x2,y2,x):
    b = (y2-y1)/(x2-x1)
    y = y1 + b*(x-x1)
    return y

def dpoly(p,V):
    m = len(p)-1
    p = np.flip(p)
    pd = np.zeros(m)
    i = 0
    while i < m:
        pd[i] = (i+1)*p[i+1]
        i = i + 1
    pd = np.flip(pd)
    return np.polyval(pd,V)
    
def best_fit_poly(V,I,poly):
    sse0 = np.var(I)*(len(I)-1)
    i = 1
    while i <= poly[0]: #poly[0] = maximum polynomial degree.
        result = np.polyfit(V,I,i,full=True)
        p = result[0]; sse = result[1][0]
        F = (len(I)-i-1)*(sse0 - sse)/sse
        if F > poly[1]:   #poly[1] = critical F-to-enter
            sse0 = sse
        else:
            break
        i = i + 1
    return p,sse
    
def dlinterp(p,V,DV):
    pV = p(V)
    b1 = (p(V+DV)-pV)/DV
    b2 = (pV-p(V-DV))/DV
    return 0.5*(b1+b2) 
        
def SDI(V,t,I,frac,ij0):
    n = len(I); nv = len(I[0])-ij0
    sd = np.zeros((nv))
    Ibar = np.zeros((nv))
    m = n - int(frac*n)
    ii = np.arange(0,m)
    t = np.delete(t,ii,0)
    I = np.delete(I,ii,0)
    ssetot = 0; df = 0
    n = len(I); dftot = 0
    fig = plt.figure(0)
    ax = fig.add_subplot(111)
    j = ij0
    while j < nv:
        Ibar[j] = np.mean(I[:,j])
        p,sse = best_fit_poly(t,I[:,j],[3,4.0])
        ssetot = ssetot + sse; df = n - len(p)
        sd[j] = np.sqrt(sse/df); dftot = dftot + df
        plt.plot(t,I[:,j],linewidth=1.0,color='b')
        Ip = np.polyval(p,t)
        plt.plot(t,Ip,'k-',linewidth=1.0)
        j = j + 1
    plt.xlabel('$t$ (ms)')
    plt.ylabel('$I$ (pA)')
    legend = ['Raw I','Smoothed']
    plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
    plt.title('Estimation of SD(I)')
    file = open('SDI.txt','w')
    file.write('%10s'%'V(mV)'+'%15s'%'MeanI(pA)'+'%15s'%'SD(pA)'+'\n')
    i = ij0
    while i < nv:
        file.write('%10.2f'%V[i]+'%15.5e'%Ibar[i]+'%15.5e'%sd[i]+'\n')
        i = i + 1
    file.close()
    return sd,Ibar,np.sqrt(sse/dftot)  

def MoveAv(y,nav0):
    if np.mod(nav0,2) == 0: nav0 = nav0 + 1
    n = len(y); ya = np.zeros(n)
    ya[0] = y[0]; ya[n-1] = y[n-1];
    i = 1
    while i < n-1:
        nav = 2*i+1
        if nav > nav0: nav = nav0
        jav = int(nav/2)
        if jav > n-1-i: 
            jav = n-1-i; nav = 2*jav + 1
        yc = np.zeros(nav)
        j = i - jav
        while j <= i+jav:
            yc[j-i+jav] = y[j]
            j = j  + 1
        ya[i] = np.mean(yc)
        i = i + 1
    return ya

def smooth(k,V,I,poly,Veval,t):
    if t == 0: poly = [1]
    m = len(poly); n = len(V)
    if m == 0:
        p = intp.interp1d(V,I,fill_value='extrapolate')
        I = np.zeros(n); I = p(Veval)
        Vrest = []; i = 1
        while i < len(I):
            if np.sign(I[i]) != np.sign(I[i-1]):
                b = (I[i]-I[i-1])/(Veval[i]-Veval[i-1])
                V0 =  -I[i-1]/b + Veval[i-1]; Vrest.append(V0)
            i = i + 1
    elif poly[0] == 'cv' or poly[0] == 'gcv':
        V = V.tolist(); I = I.tolist(); Veval = Veval.tolist()
        cv = True
        if poly[0] == 'gcv': cv = False
        if m == 1:
            p = smooth_spline(V, I, all_knots = True, cv = cv, \
                keep_data = False)
        else:
            p = smooth_spline(V, I, all_knots = True, cv = cv, \
                keep_data = False, df = n - poly[1])
        rV = robjects.FloatVector(Veval); Ihat = predict(p,rV)
        I = np.array(Ihat[1]); V = np.array(V); 
        dV = (np.max(V) - np.min(V))/30
        Vp = np.arange(np.min(V),np.max(V),dV); Vp = Vp.tolist()
        rV = robjects.FloatVector(Vp); Ihat = predict(p,rV)
        Ip = np.array(Ihat[1]); Vp = np.array(Vp);
        p = intp.PchipInterpolator(Vp,Ip,extrapolate=True)   #For convenience convert to a scipy spline that respects monotonicity
        Vrest = getVrest(0,p,V[0],V[len(V)-1])
    elif m == 1 and isinstance(poly[0], int):
        p = np.polyfit(V,I,poly[0])
        I = np.zeros(n); I = np.polyval(p,Veval)
        if poly[0] > 1:
            Vrest = getVrest(m,p,V[0],V[len(V)-1])
        else:
            Vrest = [-p[1]/p[0]]; 
    elif m == 2:
        p,dummy = best_fit_poly(V,I,poly)
        I = np.zeros(n); I = np.polyval(p,Veval)
        Vrest = getVrest(m,p,V[0],V[len(V)-1])
    else:
        p0 = np.array([poly[2]])   #polynomials of degree poly[0] and poly[1] are joined at V = poly[2]
        V1 = V.copy(); I1 = I.copy(); i1 = 0
        V2 = V.copy(); I2 = I.copy(); i2 = 0
        i = 0; n = len(V)
        while i < n:
            if V[i] <= poly[2]:
                V1[i1] = V[i]
                I1[i1] = I[i]
                i1 = i1 + 1
            else:
                V2[i2] = V[i]
                I2[i2] = I[i]
                i2 = i2 + 1
            i = i + 1
        V1 = np.resize(V1,i1)
        I1 = np.resize(I1,i1)
        V2 = np.resize(V2,i2)
        V2 = V2 - poly[2]
        I2 = np.resize(I2,i2)
        p1 = np.polyfit(V1,I1,poly[0])
        p2 = np.polyfit(V2,I2,poly[1])
        p2 = np.resize(p2,np.size(p2)-2)  #0 and 1 degree terms of polynomial 2 are estimated by fun to get a smooth and continuous join.
        p0 = np.concatenate((p0,p1,p2))
        res = op.least_squares(resids, p0, args = (V,I,poly))
        I = np.zeros(n); I = fun(res.x,Veval,poly)
        p = res.x; p1,p2 = polyparas(p,poly)
        Vrest1 = getVrest(m,p1,V[0],p[0])
        Vrest2 = getVrest(m,p2,0,V[len(V)-1]-p[0]) + p[0]
        Vrest = Vrest1; i = 0
        while i < len(Vrest2):
            Vrest.append(Vrest2[i])
            i = i + 1
    return I, Vrest, p
    
def function_parameters(blockedfile,model,user_paras):
    if model == '0': 
        paranames = ['']
    elif model == 'A^k': 
        paranames = ['i1inf','taum1']
    elif model == 'A^k+L': 
        paranames = ['i1inf','taum1','b']
    elif model == '(A^k)A': 
        paranames = ['i1inf','taum1a','taum1b']
    elif model == '(A^k)A+L': 
        paranames = ['i1inf','taum1a','taum1b','b']
    elif model == 'A^k+A': 
        paranames = ['i1inf','taum1','i2inf','taum2']
    elif model == '0+A': 
        paranames = ['i2inf','taum2']
    elif model == 'A^k+A+L': 
        paranames = ['i1inf','taum1','i2inf','taum2','b']
    elif model == '0+A+L': 
        paranames = ['i2inf','taum2','b']
    elif model == '(A^k)Ia': 
        paranames = ['i1inf','taum1','tauh1']
    elif model == '(A^k)Ib': 
        paranames = ['i1inf','taum1','b']
    elif model == '(A^k)Ic': 
        paranames = ['i1inf','taum1','tauh1','h1inf']
    elif model == '(A^k)IIa': 
        paranames = ['i1inf','taum1','tauh1','h1inf','tauh2']
    elif model == '(A^k)IIb': 
        paranames = ['i1inf','taum1','tauh1','h1inf','b']
    elif model == '(A^k)IIc': 
        paranames = ['i1inf','taum1','tauh1','h1inf','tauh2','h2inf']
    elif model == '(A^k)IId': 
        paranames = ['i1inf','taum1','tauh1','tauh2']
    elif model == '(A^k)IIe': 
        paranames = ['i1inf','taum1','tauh1','b']
    elif model == '(A^k)IIf': 
        paranames = ['i1inf','taum1','tauh1','tauh2','h2inf']
    else:
        paranames = uf.function_parameters(blockedfile,model,user_paras)
    return paranames
    
def ini_paras(blockedcdfile,t,I,f,k,V,adhocfunc,user_paras):
    n = len(I); p0 = []
    if adhocfunc != 'none':
        i = 0
        while i < n:
            I[i] = I[i] - uf.ad_hoc_i(blockedcdfile,adhocfunc,t[i],V,user_paras)
            i = i + 1
    if f == 'A^k':
        A1 = np.max(I); p0.append(A1)
        i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x); p0.append(tauA1)
    elif f == 'A^k+L':
        tb = t[np.int(0.5*n):n]
        Ib = I[np.int(0.5*n):n]
        b = np.polyfit(tb,Ib,1)
        b = b[0]; y = []; i = 0
        while i < len(I):
            y.append(I[i] - b*t[i])
            i = i + 1
        A1 = np.max(y); p0.append(A1)
        i = 0
        while i < n:
            if np.abs(y[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k)); tauA1 = t[i]/np.log(x)
        p0.append(tauA1); p0.append(b)
    elif f == '(A^k)A':
        A1 = np.max(I); p0.append(A1)
        i0 = np.int(0.5*n); m = np.argmax(I)
        tl = []; Il = []; i = 0
        while i < n:
            if i > i0 and i < m:
                Il.append(np.log(A1-I[i]))
                tl.append(t[i])
            i = i + 1
        b = np.polyfit(tl,Il,1)
        taum1b = -A1/b[0]
        i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1 
        yy = 1 - np.exp(-t[i]/taum1b)
        x = 1 - (0.5/yy)**(1/k)
        if x <= 0: x = 1 - (0.5)**(1/k)
        taum1a = -t[i]/np.log(x)
        p0.append(taum1a)
        p0.append(taum1b)
    elif f == '(A^k)A+L':
        i0 = np.int(0.5*n)
        tb = []; Ib = []; i = 0
        while i < len(I):
            if i > i0:
                tb.append(t[i])
                Ib.append(I[i])
            i = i + 1
        b = np.polyfit(tb,Ib,1); i = 0
        b = b[0]; y = []
        while i < len(I):
            y.append(I[i] - b*t[i])
            i = i + 1
        A1 = np.max(y); p0.append(A1)
        m = np.argmax(y); i0 = np.int(0.5*m); 
        tl = []; Il = []; i = 0
        while i < n:
            if i > i0 and A1 > y[i]:
                Il.append(np.log(A1-y[i]))
                tl.append(t[i])
            i = i + 1
        bt = np.polyfit(tl,Il,1)
        taum1b = -A1/bt[0]
        i = 0
        while i < n:
            if np.abs(y[i]) >= 0.5*np.abs(A1): break
            i = i + 1 
        yy = 1 - np.exp(-t[i]/taum1b)
        x = 1 - (0.5/yy)**(1/k)
        if x <= 0: x = 1 - (0.5)**(1/k)
        taum1a = -t[i]/np.log(x)
        p0.append(taum1a)
        p0.append(taum1b)
        p0.append(b)
    elif f == 'A^k+A':
        A1A2 = np.max(I); A1 = 0.5*A1A2
        p0.append(A1); A2 = A1
        i = 0
        while i < len(I):
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        p0.append(tauA1); p0.append(A2)
        i = 0
        while i < len(I):
            if (A1 - I[i]) < 0: break
            i = i + 1
        t0 = t[i]
        while i < len(I):
            if np.abs(I[i]-A1) >= 0.5*np.abs(A2): break
            i = i + 1
        x = 1/(1 - 0.5)
        tauA2 = (t[i]-t0)/np.log(x)
        p0.append(tauA2)
    elif f == '0+A':
        A2 = np.max(I); p0.append(A2)
        i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A2): break
            i = i + 1
        tauA2 = t[i]/np.log(2); p0.append(tauA2)
    elif f == 'A^k+A+L':
        tb = t[np.int(0.75*n):n]
        Ib = I[np.int(0.75*n):n]
        b = np.polyfit(tb,Ib,1)
        b = b[0]; i = 0
        A1A2 = np.max(I)-b*t[n-1]; A1 = 0.5*A1A2
        p0.append(A1); A2 = A1
        i = 0
        while i < len(I):
            if np.abs(I[i]-b*t[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        p0.append(tauA1); p0.append(A2)
        i = 0
        while i < len(I):
            if (A1-I[i]+ b*t[i]) < 0: break
            i = i + 1
        t0 = t[i]
        while i < len(I):
            if np.abs(I[i]-b*t[i]-A1) >= 0.5*np.abs(A2): break
            i = i + 1
        x = 1/(1 - 0.5)
        tauA2 = (t[i]-t0)/np.log(x)
        p0.append(tauA2); p0.append(b)
    elif f == '0+A+L':
        tb = t[np.int(0.5*n):n]
        Ib = I[np.int(0.5*n):n]
        b = np.polyfit(tb,Ib,1)
        b = b[0]; y = []; i = 0
        while i < len(I):
            y.append(I[i] - b*t[i])
            i = i + 1
        A2 = np.max(y); p0.append(A2)
        i = 0
        while i < n:
            if np.abs(y[i]) >= 0.5*np.abs(A2): break
            i = i + 1
        tauA2 = t[i]/np.log(2)
        p0.append(tauA2); p0.append(b)
    elif f == '(A^k)Ia':
        A1 = np.max(I); i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i = np.argmax(I); t0 = t[i]
        while i < n:
            if np.abs(I[i]) <= 0.5*np.abs(A1): break
            i = i + 1
        tauI1 = (t[i]-t0)/np.log(2)
        p0.append(A1); p0.append(tauA1); p0.append(tauI1)
    elif f == '(A^k)Ib':
        imax = np.argmax(I); i = imax; Ilin = []; tlin = []
        while i < n:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        tlin = np.array(tlin); Ilin = np.array(Ilin) 
        p = np.polyfit(tlin,Ilin,1)
        A1 = p[1]; b = -p[0]/p[1]
        i = 0
        while i < imax:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        p0.append(A1); p0.append(tauA1); p0.append(b)
    elif f == '(A^k)Ic':
        i1 = int(0.9*len(I)); i2 = len(I)
        Iinf = np.mean(I[i1:i2]);
        A1 = np.max(I); h1inf = Iinf/A1; i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i = np.argmax(I); t0 = t[i]
        while i < n:
            if np.abs(I[i]-I[n-1]) <= 0.5*np.abs(A1-I[n-1]): break
            i = i + 1
        tauI1 = (t[i]-t0)/np.log(2)
        p0.append(A1); p0.append(tauA1)
        p0.append(tauI1); p0.append(h1inf)
    elif f == '(A^k)IIa':
        A1 = np.max(I); i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        imax = np.argmax(I);
        i1 = int(0.3*(len(I)-imax))+imax
        i2 = imax+int(0.1*len(I))
        i = imax; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI1 = -(I[imax]-I[i1])/p[0]
        h1inf = I[i2]/I[imax]
        i2 = i1+int(0.1*len(I))
        i = i1; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI2 = -(I[i1]-I[len(I)-1])/p[0]
        p0.append(A1); p0.append(tauA1)
        p0.append(tauI1); p0.append(h1inf); p0.append(tauI2)
    elif f == '(A^k)IIb':
        A1 = np.max(I); i = int(0.7*n)
        Ilin = []; tlin = []
        while i < n:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        tlin = np.array(tlin); Ilin = np.array(Ilin) 
        p = np.polyfit(tlin,Ilin,1)
        h1inf = p[1]/A1; b = -p[0]/p[1]
        imax = np.argmax(I); i = 0    
        while i < imax:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i = imax; t0 = t[i]
        while i < n:
            y = I[i] - p[1] - p[0]*t[i]
            if y < 0.5*abs(A1): break
            i = i + 1
        # i = len(I)-1; t0 = t[imax]
        # while i > imax:
        #     y = I[i] - p[1] - p[0]*t[i]
        #     if y > 0.5*abs(A1-p[1]): break
        #     i = i - 1
        tauI1 = (t[i]-t0)/np.log(2)
        p0.append(A1); p0.append(tauA1)
        p0.append(tauI1); p0.append(h1inf); p0.append(b)
    elif f == '(A^k)IIc':
        i1 = int(0.9*len(I)); i2 = len(I)
        Iinf = np.mean(I[i1:i2]);
        A1 = np.max(I); imax = np.argmax(I); i = 0    
        while i < imax:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i1 = int(0.3*(len(I)-imax))+imax
        i2 = imax+int(0.1*len(I))
        i = imax; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI1 = -(I[imax]-I[i1])/p[0]
        h1inf = I[i2]/I[imax]
        i2 = i1+int(0.1*len(I))
        i = i1; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI2 = -(I[i1]-I[len(I)-1])/p[0]
        h2inf = I[len(I)-1]/(h1inf*I[imax])
        p0.append(A1); p0.append(tauA1); p0.append(tauI1)
        p0.append(h1inf); p0.append(tauI2); p0.append(h2inf)
    elif f == '(A^k)IId':
        A1 = np.max(I); i = 0
        while i < n:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        imax = np.argmax(I)
        i1 = int(0.3*(len(I)-imax))+imax
        i2 = imax+int(0.1*len(I))
        i = imax; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI1 = -I[imax]/p[0]
        i2 = i1+int(0.1*len(I))
        i = i1; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI2 = -I[i1]/p[0]
        p0.append(A1); p0.append(tauA1)
        p0.append(tauI1); p0.append(tauI2)
    elif f == '(A^k)IIe':
        A1 = np.max(I); i = int(0.7*n)
        imax = np.argmax(I); t0 = t[imax]
        Ilin = []; tlin = []
        while i < n:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        tlin = np.array(tlin); Ilin = np.array(Ilin) 
        p = np.polyfit(tlin,Ilin,1); b = -p[0]/p[1]
        i = 0    
        while i < imax:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i = len(I)-1
        while i > imax:
            y = I[i] - p[1] - p[0]*t[i]
            if y > 0.5*abs(A1-p[1]-p[0]*t0): break
            i = i - 1
        tauI1 = (t[i]-t0)/np.log(2)
        p0.append(A1); p0.append(tauA1)
        p0.append(tauI1); p0.append(b)
    elif f == '(A^k)IIf':
        i1 = int(0.9*len(I)); i2 = len(I)
        Iinf = np.mean(I[i1:i2]);
        A1 = np.max(I); imax = np.argmax(I); i = 0    
        while i < imax:
            if np.abs(I[i]) >= 0.5*np.abs(A1): break
            i = i + 1
        x = 1/(1 - 0.5**(1/k))
        tauA1 = t[i]/np.log(x)
        i1 = int(0.3*(len(I)-imax))+imax
        i2 = imax+int(0.1*len(I))
        i = imax; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI1 = -(I[imax]-I[i1])/p[0]
        i2 = i1+int(0.1*len(I))
        i = i1; Ilin = []; tlin = []
        while i < i2:
            tlin.append(t[i]); Ilin.append(I[i])
            i = i + 1
        p = np.polyfit(tlin,Ilin,1)
        tauI2 = -I[i1]/p[0]
        h2inf = I[len(I)-1]/I[imax]
        p0.append(A1); p0.append(tauA1); p0.append(tauI1)
        p0.append(tauI2); p0.append(h2inf)
    elif f != '0':
        p0 = uf.ini_paras(blockedcdfile,t,I,f,k,V,user_paras)
    if adhocfunc != 'none':
        i = 0
        while i < n:
            I[i] = I[i] + uf.ad_hoc_i(blockedcdfile,adhocfunc,t[i],V,user_paras)
            i = i + 1
    return p0

def it(blockedfile,p,t,f,k,V,adhocfunc,user_paras):
    if f == '0': 
        i = 0
    elif f == 'A^k':
        i1inf = p[0]; taum1 = p[1]
        i = i1inf*(1 - np.exp(-t/taum1))**k
    elif f == 'A^k+L':
        i1inf = p[0]; taum1 = p[1]; b = p[2]
        i = i1inf*(1 - np.exp(-t/taum1))**k + b*t
    elif f == '(A^k)A':
        i1inf = p[0]; taum1a = p[1]; taum1b = p[2]
        i = i1inf*((1 - np.exp(-t/taum1a))**k)*(1 - np.exp(-t/taum1b))
    elif f == '(A^k)A+L':
        i1inf = p[0]; taum1a = p[1]; taum1b = p[2]; b = p[3]
        i = i1inf*((1 - np.exp(-t/taum1a))**k)*(1 - np.exp(-t/taum1b)) + b*t
    elif f == 'A^k+A':
        i1inf = p[0]; taum1 = p[1]; i2inf = p[2]; taum2 = p[3]
        i = i1inf*(1 - np.exp(-t/taum1))**k + i2inf*(1 - np.exp(-t/taum2))
    elif f == '0+A':
        i2inf = p[0]; taum2 = p[1]
        i = i2inf*(1 - np.exp(-t/taum2))
    elif f == 'A^k+A+L':
        i1inf = p[0]; taum1 = p[1]; i2inf = p[2]; taum2 = p[3]; b = p[4]
        i = i1inf*(1 - np.exp(-t/taum1))**k + i2inf*(1 - np.exp(-t/taum2)) + b*t
    elif f == '(A^k)Ia':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]
        i = i1inf*((1-np.exp(-t/taum1))**k)*np.exp(-t/tauh1)
    elif f == '(A^k)Ib':
        i1inf = p[0]; taum1 = p[1]; b = p[2]
        i = i1inf*((1-np.exp(-t/taum1))**k)*(1-b*t)
    elif f == '(A^k)Ic':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; h1inf = p[3]
        i = i1inf*((1-np.exp(-t/taum1))**k)*((1-h1inf)*np.exp(-t/tauh1) + h1inf)
    elif f == '(A^k)IIa':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; h1inf = p[3]; tauh2 = p[4]
        i = i1inf*((1-np.exp(-t/taum1))**k)*((1-h1inf)*np.exp(-t/tauh1) + h1inf)*np.exp(-t/tauh2)
    elif f == '(A^k)IIb':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; h1inf = p[3]; b = p[4]
        i = i1inf*((1-np.exp(-t/taum1))**k)*((1-h1inf)*np.exp(-t/tauh1) + h1inf)*(1-b*t)
    elif f == '(A^k)IIc':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; h1inf = p[3]; tauh2 = p[4]; h2inf = p[5]
        i = i1inf*((1-np.exp(-t/taum1))**k)*((1-h1inf)*np.exp(-t/tauh1) + h1inf)*((1-h2inf)*np.exp(-t/tauh2) + h2inf)
    elif f == '(A^k)IId':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; tauh2 = p[3]
        i = i1inf*((1-np.exp(-t/taum1))**k)*(np.exp(-t/tauh1))*np.exp(-t/tauh2)
    elif f == '(A^k)IIe':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; b = p[3]
        i = i1inf*((1-np.exp(-t/taum1))**k)*(np.exp(-t/tauh1))*(1-b*t)
    elif f == '(A^k)IIf':
        i1inf = p[0]; taum1 = p[1]; tauh1 = p[2]; tauh2 = p[3]; h2inf = p[4]
        i = i1inf*((1-np.exp(-t/taum1))**k)*(np.exp(-t/tauh1))*((1-h2inf)*np.exp(-t/tauh2) + h2inf)
    else:
        i = uf.it(blockedfile,p,t,f,k,V,user_paras)
    if adhocfunc != 'none': i = i + uf.ad_hoc_i(blockedfile,adhocfunc,t,V,user_paras)
    return i

def iresids(p,blockedfile,t,i,f,k,V,adhocfunc,user_paras):
    n = len(t); ihat = np.zeros(n)
    j = 0
    while j < n:
        ihat[j] = it(blockedfile,p,t[j],f,k,V,adhocfunc,user_paras)
        j = j + 1
    return i - ihat
        
def resids(p,V,I,poly):
    Ihat = fun(p,V,poly)
    return I-Ihat
    
def estimate_tau(V,tau,extrap,tau0):
    n = len(tau); i = 0
    Dtau = tau[n-1]-tau0
    b = Dtau/(V[n-1]-V[0])
    while i < n-1:
        if extrap == 'last': 
            tau[i] = tau[n-1]
        elif extrap == 'constant': 
            tau[i] = tau0
        elif extrap == 'linear': 
            tau[i] = tau0 + b*(V[i]-V[0])
        else: 
            tauV = -float(extrap)/np.log(0.5)
            tau[i] = Dtau*np.exp((V[i]-V[n-1])/tauV) + tau0
        i = i + 1
    return tau
    
def impute_tau(fullmodel,V,tau,tau_extrap_low,tau_low,tau_extrap_high,tau_high):
    n = len(V); inz = np.nonzero(tau); m = len(inz[0])
    if m > 0:
        inz = np.sort(inz); ilo = inz[0][0]; ihi = inz[0][m-1]
        i = ilo+1
        while i < ihi:
            if tau[i] <= 0: 
                if '(A^k)A' in fullmodel:
                    tau[i] = 0.1
                else:
                    tau[i] = 0.5*(tau[i-1]+tau[i+1])
            i = i + 1
        if m < len(tau):
            if ilo > 0: tau[0:ilo+1] = estimate_tau(V[0:ilo+1],tau[0:ilo+1],tau_extrap_low,tau_low)
            if ihi < n-1: 
                Vrev = V[ihi:n]; Vrev = np.flip(Vrev)
                taurev = tau[ihi:n]; taurev = np.flip(taurev)
                taurev = estimate_tau(Vrev,taurev,tau_extrap_high,tau_high)
                tau[ihi:n] = np.flip(taurev)
    return tau
            
def fun(p,V,poly): 
    n = len(V); I = np.zeros(n)
    #if p[0] < -70: p[0] = -70
    p1,p2 = polyparas(p,poly)
    i = 0
    while i < n:
        if V[i] <= p[0]:   #polynomials p1 and p2 are joined at V = p[0]
            I[i] = np.polyval(p1,V[i])
        else:
            I[i] = np.polyval(p2,V[i]-p[0])
        i = i + 1
    return I
    
def polyparas(p,poly):
    np1 = poly[0]+1   #poly[0] = degree of polynomial 1
    p1 = np.zeros(np1)
    i = 0
    while i < np1:
        p1[i] = p[i+1]
        i = i + 1
    np2 = poly[1]+1   #poly[1] = degree of polynomial 2
    p2 = np.zeros(np2)
    i = 0
    while i < np2-2:
        p2[i] = p[np1+1+i]
        i = i + 1
    p2[i] = dpoly(p1,p[0])  #0 and 1 degree terms of polynomial 2 are estimated from polynomial 1 to get a smooth and continuous join.  
    p2[i+1] = np.polyval(p1,p[0])
    return p1, p2

def solveODE(time,V,Vrest,A,gamma,DV,p,poly,Istar0,bL,V0,options,print_warnings):
    if time == 0: poly = [1]
    m = len(poly)
    if m == 0:
        dIstar_dV0 = dlinterp(p,Vrest,DV)
    elif (m == 1 or m == 2) and isinstance(poly[0], int):
        dIstar_dV0 = dpoly(p,Vrest)
    elif 'cv' in str(poly[0]):
        pd = p.derivative(); dIstar_dV0 = pd(Vrest)
    else:
        p1,p2 = polyparas(p,poly)
        if Vrest <= p[0]:
            dIstar_dV0 = dpoly(p1,Vrest)
        else:
            dIstar_dV0 = dpoly(p2,Vrest-p[0])
    factor = gamma*gamma + 16*gamma*A*dIstar_dV0
    if factor >= 0:
    #if dIstar_dV0 > 0:
        slope = (gamma + 8*A*dIstar_dV0 - np.sqrt(factor))/(8*A*A)
    else:
        slope = (gamma + 8*A*dIstar_dV0)/(8*A*A)
        #slope = gamma/(8*A*A)
        if print_warnings == 'yes':
            print("WARNING: (dI/dV)_Vrest < -gamma/(16*A) in Eq. (3).")
            print("         Setting the sqrt term = 0 at t = "+str(time)+" ms.")
            #print("         Setting (dI*/dV)_Vrest = 0 at t = "+str(time)+" ms.")
    Ve0 = []; Ve1 = []; Ve2 = []
    Ve01 = Vrest-DV; Ve02 = Vrest+DV
    n = len(V); i = 0
    while i < n:
        if V[i] < Ve01: 
            Ve1.append(V[i])
        elif V[i] > Ve02: 
            Ve2.append(V[i])
        else:
            Ve0.append(V[i])
        i = i + 1
    Ve1 = np.array(Ve1); Ve2 = np.array(Ve2)
    Ve1 = np.flip(-np.array(Ve1)); Ve01 = -Ve01
    n1 = len(Ve1); n2 = len(Ve2); n0 = len(Ve0)
    cd1 = np.zeros(n1); cd2 = np.zeros(n2)
    #options = {'rtol': 1e-3,'atol': 1e-6,'max_step': 0.01}
    if n1 > 0:
        cd0 = np.array([-slope*DV]); mult = -1
        sol1 = ode.solve_ivp(fun=lambda t,y: dcddV(t,y,A,gamma,p,poly,mult,DV,time,Istar0,bL,V0),t_span=(Ve01,Ve1[n1-1]),y0=cd0,t_eval=Ve1,method='RK45',**options)  
        cd1 = sol1.y[0]; cd1 = np.flip(cd1)
    if n2 > 0:
        cd0 = np.array([slope*DV]); mult = 1
        sol2 = ode.solve_ivp(fun=lambda t,y: dcddV(t,y,A,gamma,p,poly,mult,DV,time,Istar0,bL,V0),t_span=(Ve02,Ve2[n2-1]),y0=cd0,t_eval=Ve2,method='RK45',**options)
        cd2 = sol2.y[0]
    cd0 = np.zeros(n0)
    if n0 > 0: 
        i = 0
        while i < n0:
            cd0[i] = slope*(Ve0[i]-Vrest)
            i = i + 1
    cd = np.concatenate((cd1,cd0,cd2))
    return cd

def dcddV(V,cd,A,gamma,p,poly,mult,DV,t,Istar0,bL,V0):
    if t == 0: poly = [1]
    V = mult*V; m = len(poly)
    if m == 0:
        Istar = p(V)
        dIstar_dV = dlinterp(p,V,DV)
    elif (m == 1 or m == 2) and isinstance(poly[0], int):
        Istar = np.polyval(p,V)
        dIstar_dV = dpoly(p,V)
    elif 'cv' in str(poly[0]):
        Istar = p(V)
        pd = p.derivative()
        dIstar_dV = pd(V)
    else:
        p1,p2 = polyparas(p,poly)
        if V <= p[0]:
            Istar = np.polyval(p1,V)
            dIstar_dV = dpoly(p1,V)
        else:
            Istar = np.polyval(p2,V-p[0])
            dIstar_dV = dpoly(p2,V-p[0])
    """
    IstarL = Istar0 + bL*(V-V0)
    if V < -75 or Istar < IstarL: 
        Istar = IstarL
        dIstar_dV = bL 
    """
    dcd_dV = mult*(gamma*cd[0]/(4*(A*cd[0]-Istar)) + dIstar_dV)/A
    return dcd_dV
    
def CorrectVpulse(k,tbreak,A,Ra,t=[],V=[],I=[],d=[],Raccess=0, color=['0.6','0.8'], 
                    Rseal=np.Inf,LJP=0.0,poly=[5,4.0],DV=0.1, Iunit='pA', cdL_method = 1, 
                    V_LJP_corrected = 'yes', data_lw = 5.0, criterion = 'I&Icap', 
                    tDIfile = '', flagfile = 'flag.txt', ok = 1, tunit='ms',
                    do_plots='no', options = {}, cwd = os.getcwd(), delim = '', 
                    parameter_file = 'parameters.txt', minSD = -1, skip = 0, 
                    coxdir='CorrectCoxVpulse', maxIerror_tol = 1.0, maxit = 9):
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    i = 0; tbreak = [0,0,0]; Ihold = 0; Rinput = np.Inf; tplot = []
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        if len(v) > 2:
            j = 2
            while j < len(v):
                v[1] = v[1] + ':'+v[j]
                j = j + 1
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'maxit': maxit = int(v[1])
            if v[0] == 'Stop_on_minimum_RMS_error': MinErrorStop = v[1]
            if v[0] == 'I*(V)_interpolation': Linear_interpolation = v[1]
            if v[0] == 'Decimate_data_by_a_factor_of': 
                if len(v) > 1:
                    v = v[1].split()
                    dec = []; j = 0
                    while j < len(v):
                        dec.append(float(v[j]))
                        if dec[j] > 0 and dec[j] < 1: dec[j] = 1/dec[j]
                        dec[j] = int(dec[j])
                        j = j + 1
                else:
                    dec = []
            if v[0] == 'Moving_average_window_(ms)': avint = float(v[1])
            if v[0] == 'Spline_smoothing_of_I(t)': do_smoothIt = v[1]
            if v[0] == 'Fraction_of_trace_for_estimating_SD(I)': frac = float(v[1])
            if v[0] == '|DV|(mV)': DV = float(v[1])
            if v[0] == 'Iunit': Iunit = v[1]
            if v[0] == 'tunit': tunit = v[1]
            if v[0] == 'Data_delimeter': 
                delim = v[1]
                if delim == 'tab': delim = '\t'
                if delim == 'space': delim = ''
            if v[0] == 'Number_of_header_lines_to_skip_(excluding_column_names)': skip = int(v[1])
            if v[0] == 'V_LJP_corrected': V_LJP_corrected = v[1]
            if v[0] == 'Print_warnings_(yes/no)': print_warnings = v[1]
            if v[0] == 'Leak-subtracted_currents_in_file': tDIfile = v[1]
            if v[0] == 'Model_parameter_file_for_blocked_condition': rescdfile = v[1]
            if v[0] == 'Method_for_estimating_the_leak_current_density_iL_(0-3)': cdL_method = int(v[1])
            if v[0] == 'Area(um^2)': A = float(v[1])
            if v[0] == 'Ra(Ohm.cm)': Ra = float(v[1])
            if v[0] == 'Raccess(MOhm)': Raccess = float(v[1])
            if v[0] == 'Rseal(GOhm)': Rseal = float(v[1])
            if v[0] == 'LJP(mV)': LJP = float(v[1])
            if v[0] == 'diam(um)': 
                v = v[1].split()
                d = []; j = 0
                while j < len(v):
                    d.append(float(v[j]))
                    j = j + 1
            if v[0] == 'tstart(ms)': tbreak[1] = float(v[1])
            if v[0] == 'tstop(ms)': tbreak[2] = float(v[1])     
            if v[0] == 'Ihold(pA)': Ihold = float(v[1]) 
            if v[0] == 'Leak-subtraction_DV(mV)': lsDV = float(v[1]) 
            if v[0] == 'Leak-subtraction_DI(pA)': lsDI = float(v[1]) 
            if v[0] == 'Vhold(mV)': Vhold = float(v[1]) 
            if v[0] == 'Vcmnd(mV)': 
                v = v[1].split()
                Vcmnd = []; j = 0
                while j < len(v):
                    Vcmnd.append(float(v[j]))
                    j = j + 1
            if v[0] == 'Plot_I(V)_or_I*(V)_at_these_times_(ms;_max=12)': 
                v = v[1].split(); j = 0
                while j < len(v):
                    if j > 11: break
                    tplot.append(float(v[j]))
                    j = j + 1
            if v[0] == 'poly': 
                v = v[1].split()
                poly = []; j = 0
                while j < len(v):
                    if j == 0 and 'cv' in v[j]:
                        poly.append(v[j])
                    elif j == 0 or (j == 1 and len(v) == 3):
                        poly.append(int(v[j]))
                    else:
                        poly.append(float(v[j]))
                    j = j + 1
        i = i + 1
    Vcmnd.insert(0,Vhold); V = np.array(Vcmnd); nv = len(V)
    if V_LJP_corrected == 'no': V = V - LJP
    if k == 0:
        try:
            os.chdir(coxdir)
            os.chdir(cwd)
            shutil.rmtree(coxdir, ignore_errors=True)
            os.rmdir(coxdir)
            os.mkdir(coxdir)
        except FileNotFoundError:
            os.mkdir(coxdir)
        if len(tDIfile) > 0: t,I = load_tVI(tDIfile,skip=skip,delim=delim)
        if Iunit != 'pA': I = 1000*I  #nA -> pA
        if tunit != 'ms': t = 1000*t  #s -> ms
        t,I = extract(t,I,tbreak); I = np.insert(I,0,0,axis=1)
        if len(dec) > 0: t,I = decimate(t,I,dec)
        rawI = I.copy(); rawt = t.copy()
        #rawt, rawI = extract(rawt,rawI,tbreak)
        save_tVI('Raw_tDI.txt',rawt,Vcmnd,rawI)
        Vt = np.full_like(I,0); Eseal = -LJP
        Rinput = lsDV/lsDI
        n = len(t); j = 0
        while j < nv:
            i = 0
            while i < n:
                #I[i,j] = I[i,j] + (V[j]-Vhold)/Rinput + Ihold
                I[i,j] = I[i,j] + (Vcmnd[j]-Vhold)/Rinput + Ihold
                Vt[i,j] = V[j] - I[i,j]*Raccess*1e-3
                I[i,j] = I[i,j] - (Vt[i,j]-Eseal)/Rseal
                i = i + 1
            j = j + 1
        Vhold = Vhold - Ihold*Raccess*1e-3
        Ihold = Ihold - (Vhold-Eseal)/Rseal
        V = np.mean(Vt,0)
        file = open('IholdVholdVcrctVrestSDI.txt','w')
        file.write('Ihold(pA): %7.2f'%Ihold+'\r')
        file.write('Vhold(mV): %7.2f'%Vhold+'\r') 
        file.write('Vstep(mV): ')
        j = 1
        while j < nv:
            file.write('%8.1f'%V[j])
            j = j + 1
        file.write('\r')
        file.close()
        if avint > 0: 
            dt = t[1]-t[0]; nav0 = int(avint/dt)
            i = 0
            while i < nv:
                I[:,i] = MoveAv(I[:,i],nav0)
                i = i + 1
        sdI,Ibar,SDtol = SDI(V,t,I,frac,1)
        do_smoothIt = 'no'  #doesn't work very well
        if do_smoothIt == 'yes': 
            psd,ssesd = best_fit_poly(Ibar,sdI,[3,4.0])
            Iobs = I.copy()
            j = 1
            while j < nv:
                sdI = np.polyval(psd,I[:,j]); w = 1/sdI
                p = intp.UnivariateSpline(t,I[:,j],w); I[:,j] = p(t)
                j = j + 1
            kk = 1
            while kk < nv:
                if kk == 1:
                    fig = plt.figure()
                    ax = fig.add_subplot(111)
                plt.plot(t,Iobs[:,kk],linewidth=1.0,color='0.6')
                plt.plot(t,I[:,kk],'k-',linewidth=1.0)
                kk = kk + 1
            plt.xlabel('$t$ (ms)')
            plt.ylabel('$I$ (pA)')
            legend = ['Observed $I$','Smoothed $I$']
            plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
            plt.title('Spline-smoothed leak-subtracted currents')
        if Raccess > 0:
            kk = 0
            while kk < nv:
                if kk == 0:
                    fig = plt.figure()
                    ax = fig.add_subplot(111)
                plt.plot([0,t[n-1]],[Vcmnd[kk],Vcmnd[kk]],'k--',linewidth=1.0)
                plt.plot(t,Vt[:,kk],'k-',linewidth=1.0)
                kk = kk + 1
            plt.xlabel('$t$ (ms)')
            plt.ylabel('$V$ (mV)')
            legend = ['Command V','Corrected V']
            plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
            plt.title('Effect of an access resistance on $V$')
        save_tVI('Crct_tV.txt',t,Vcmnd,Vt,'V(mV')
        save_tVI('Crct_tDI.txt',t,Vcmnd,I)
        Istar_k = I.copy(); result = {}
    else:
        rawt,rawI = load_tVI('Raw_tDI.txt')
        t,I = load_tVI('Crct_tDI.txt'); n = len(t)
        file = open('Ihold_DI.txt','r')
        data = file.readlines(); file.close()
        v = data[0].split(); predIhold = float(v[1])
        v = data[1].split(); predDI = float(v[1])
        tp,predI0 = load_tVI('tDIpred.txt')
        tp,predI0 = extract(tp,predI0,tbreak);
        predI0 = np.insert(predI0,0,0,axis=1)
        if Iunit != 'pA': predI0 = 1000*predI0  #nA -> pA
        Rinput = lsDV/predDI; predI = np.full_like(I,0)
        Vt = np.full_like(I,0); error = np.full_like(I,0)
        Eseal = -LJP; SSE = 0; j = 0
        while j < nv:
            p = intp.interp1d(tp,predI0[:,j],fill_value='extrapolate')
            predI[:,j] = p(t); i = 0
            while i < n:
                error[i,j] = rawI[i,j] - predI[i,j]
                SSE = SSE + error[i,j]*error[i,j]
                #predI[i,j] = predI[i,j] + (V[j]-Vhold)/Rinput + predIhold
                predI[i,j] = predI[i,j] + (Vcmnd[j]-Vhold)/Rinput + predIhold
                Vt[i,j] = V[j] - predI[i,j]*Raccess*1e-3
                predI[i,j] = predI[i,j] - (Vt[i,j]-Eseal)/Rseal
                i = i + 1
            j = j + 1
        e_k1 = np.zeros([n,nv])
        j = 0
        while j < nv:
            i = 0
            while i < n:
                e_k1[i,j] = I[i,j] - predI[i,j]
                i = i + 1
            j = j + 1
        save_tVI(coxdir+'/Ierror_'+str(k-1)+'.txt',t,Vcmnd,e_k1,'e(pA)')
        rmserror = np.sqrt(SSE/(nv*n))
        result = {'RMS error (pA)': rmserror}
        
        if do_plots == 'yes':
            fig = plt.figure()
            j = 0
            while j < nv:
                plt.plot(t,I[:,j],'b-')
                plt.plot(t,predI[:,j],'k-')
                j = j + 1
            plt.xlabel('$t$ (ms)')
            plt.ylabel('$I$ (pA)')
            legend = ['Observed $I$','Predicted $I$']
            plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
            plt.title('k = '+str(k-1)+': Total current (including leak)')

        save_tVI(coxdir+'/Iresids_'+str(k-1)+'.txt',t,Vcmnd,error,'res(pA)')
        try:
            shutil.copy('cdn.txt', coxdir+'/cdn_'+str(k-1)+'.txt')
        except FileNotFoundError:
            pass
        shutil.copy('tDIpred.txt', coxdir+'/tDIpred_'+str(k-1)+'.txt')
        shutil.copy('Ihold_DI.txt', coxdir+'/Ihold_DI_'+str(k-1)+'.txt')
        if ok == -1 or (MinErrorStop == 'yes' and minSD > 0 and rmserror > minSD): return result
        
        Istarf = coxdir+'/Istar_'+str(k-1)+'.txt'
        t,Istar_k1 = load_tVI(Istarf)
        linterp = np.zeros([n,nv]); fsave = np.zeros([n,nv])
        x1 = np.zeros([n,nv]); x2 = np.zeros([n,nv])
        fx1 = np.zeros([n,nv]); fx2 = np.zeros([n,nv])
        F1 = np.zeros([n,nv]); F2 = np.zeros([n,nv])
        if k > 1:
            j = 0
            while j < nv:
                linterpf = coxdir+'/linterp_'+str(Vcmnd[j])+'_'+str(k-1)+'.txt'
                M,dummy,dummy = load_matrix(linterpf)
                linterp[:,j] = M[:,0]
                x1[:,j] = M[:,1]; fx1[:,j] = M[:,2]
                x2[:,j] = M[:,3]; fx2[:,j] = M[:,4]
                fsave[:,j] = M[:,5]; F1[:,j] = M[:,6]; F2[:,j] = M[:,7]
                j = j + 1
            linterp = linterp.astype(int)
            Istarf = coxdir+'/Istar_'+str(k-2)+'.txt'
            t,Istar_k2 = load_tVI(Istarf)
            file = coxdir+'/Ierror_'+str(k-2)+'.txt'
            t,e_k2 = load_tVI(file)
            if k > 2:
                Istarf = coxdir+'/Istar_'+str(k-3)+'.txt'
                t,Istar_k3 = load_tVI(Istarf)
                file = coxdir+'/Ierror_'+str(k-3)+'.txt'
                t,e_k3 = load_tVI(file)
        Istar_k = np.zeros([n,nv]); i = 0
        while i < n:
            j = 0
            while j < nv:
                if k == 1:
                    Istar_k[i,j] = Istar_k1[i,j] + e_k1[i,j]
                elif Linear_interpolation == 'simple':
                    if np.sign(e_k1[i,j]) == np.sign(e_k2[i,j]):
                        Istar_k[i,j] = Istar_k1[i,j] + e_k1[i,j]
                    else:
                        Istar_k[i,j] = Istar_k1[i,j] - e_k1[i,j]*(Istar_k1[i,j] - Istar_k2[i,j])/(e_k1[i,j] - e_k2[i,j])
                elif Linear_interpolation == 'standard':
                    if k == 2 or linterp[i,j] == 0:
                        if np.sign(e_k1[i,j]) == np.sign(e_k2[i,j]):
                            Istar_k[i,j] = Istar_k1[i,j] + e_k1[i,j]
                        else:
                            x1[i,j] = Istar_k2[i,j]; fx1[i,j] = e_k2[i,j]
                            x2[i,j] = Istar_k1[i,j]; fx2[i,j] = e_k1[i,j]
                            Istar_k[i,j] = x2[i,j] - fx2[i,j]*(x2[i,j] - x1[i,j])/(fx2[i,j] - fx1[i,j])
                            linterp[i,j] = 1
                    else:
                        x3 = Istar_k1[i,j]; fx3 = e_k1[i,j]
                        if fx2[i,j] - fx1[i,j] == 0:
                            Istar_k[i,j] = x3 + fx3
                        else:
                            if np.sign(fx3) != np.sign(fx1[i,j]):
                                x2[i,j] = x3; fx2[i,j] = fx3
                            else:
                                x1[i,j] = x3; fx1[i,j] = fx3
                            Istar_k[i,j] = x2[i,j] - fx2[i,j]*(x2[i,j] - x1[i,j])/(fx2[i,j] - fx1[i,j])
                else:                        
                    if k == 2 or linterp[i,j] == 0:
                        if np.sign(e_k1[i,j]) == np.sign(e_k2[i,j]):
                            Istar_k[i,j] = Istar_k1[i,j] + e_k1[i,j]
                        else:
                            x1[i,j] = Istar_k2[i,j]; fx1[i,j] = e_k2[i,j]
                            x2[i,j] = Istar_k1[i,j]; fx2[i,j] = e_k1[i,j]
                            Istar_k[i,j] = x2[i,j] - fx2[i,j]*(x2[i,j] - x1[i,j])/(fx2[i,j] - fx1[i,j])
                            linterp[i,j] = 1; fsave[i,j] = fx2[i,j]
                            F1[i,j] = fx1[i,j]; F2[i,j] = fx2[i,j]
                    else:
                        x3 = Istar_k1[i,j]; fx3 = e_k1[i,j]
                        if fx2[i,j] - fx1[i,j] == 0:
                            Istar_k[i,j] = x3 + fx3
                        else:
                            if np.sign(fx3) != np.sign(F1[i,j]):
                                x2[i,j] = x3; F2[i,j] = fx3
                                if np.sign(fx3) == np.sign(fsave[i,j]):
                                    F1[i,j] = 0.5*F1[i,j]
                            else:
                                x1[i,j] = x3; F1[i,j] = fx3
                                if np.sign(fx3) == np.sign(fsave[i,j]):
                                    F2[i,j] = 0.5*F2[i,j]
                            fsave[i,j] = fx3
                            Istar_k[i,j] = x2[i,j] - F2[i,j]*(x2[i,j] - x1[i,j])/(F2[i,j] - F1[i,j])
                j = j + 1
            i = i + 1
    if k > 0: 
        file = open('IholdVholdVcrctVrestSDI.txt','r')
        data = file.readlines(); file.close()
        v = data[2].strip('\n'); v = v.split(':')
        v = v[1].split(); V = []; i = 0
        while i < len(v):
            V.append(float(v[i]))
            i = i + 1
        v = data[1].strip('\n'); v = v.split(':')
        Vhold = float(v[1]); V = np.array(V)
        V = np.insert(V,0,Vhold,axis=0)
    Istar = np.full_like(Istar_k,0)
    Vrest = []; p = []; i = 0
    while i < n:
        Vrest.append([]); p.append([])
        Istar[i,:],Vrest[i],p[i] = smooth(k,V,Istar_k[i,:],poly,V,t[i])        
        if i == 0:
            Istar0 = p[0][1] + p[0][0]*V[0]
            bL = p[0][0]
        i = i + 1
    save_tVI(coxdir+'/Istar_'+str(k)+'.txt',t,Vcmnd,Istar)
    itplot = []; itp = 0; kk = 0
    while kk < n and itp < len(tplot):
        if t[kk] >= tplot[itp]:
            itplot.append(kk)
            itp = itp + 1
        kk = kk + 1
    if k == 0 or do_plots == 'yes': 
        Vplot = np.zeros(1000); Iplot = np.zeros(1000)
        dV = (V[nv-1]-V[0])/999; kk = 0
        while kk < 1000:
            Vplot[kk]= V[0] + kk*dV
            kk = kk + 1
        ls = ['k-','k--','k-.','k:','b-','b--','b-.','b:','y-','y--','y-.','y:']
        col = ['k','k','k','k','b','b','b','b','y','y','y','y']
        legend = []; kk = 0
        while kk < len(tplot):
            legend.append(str(tplot[kk]))
            if kk == 0:
                fig = plt.figure()
                ax = fig.add_subplot(111)
            plt.scatter(V,Istar_k[itplot[kk],:],marker='o',color=col[kk])
            Iplot,dummy,dummy = smooth(k,V,Istar_k[itplot[kk],:],poly,Vplot,tplot[kk])            
            plt.plot(Vplot,Iplot,ls[kk],linewidth=1.0)
            kk = kk + 1
        plt.legend(legend, fontsize=10, title='ms', ncol=1, loc = 'best')
        plt.xlabel('$V$ (mV)')
        if k == 0:
            plt.ylabel('$I$ (pA)')
            plt.title('k = '+str(k)+': $I$ with fitted smoothing functions')
        else:
            plt.ylabel('$I$* (pA)')
            plt.title('k = '+str(k)+': $I$* with fitted smoothing functions')
    
    print('')
    print('Estimating current density, i(t,V)')
    sumd32 = 0; i = 0
    while i < len(d):
        sumd32 = sumd32 + d[i]**(3/2)
        i = i + 1
    gamma = (np.pi**2/Ra)*sumd32*sumd32*1e5  #(pA/mV)um^2 with Ra in Ohm*cm
    nVrest = []; cd = []; cdt = []; nduds = 0; i = 0
    while i < n:
        if np.remainder(t[i],100) == 0: print('%8.1f'%t[i], ' ms')
        impute_Vrest = 'no'
        if len(Vrest[i]) == 0:
            if print_warnings == 'yes': print("WARNING: Unable to estimate Vrest at t = "+str(t[i])+" ms; omitting these data.")
            if impute_Vrest == 'yes':
                m = len(poly)
                if m < 3:
                    Vrest[i] = EstimateVrest(i,1,poly,p[i],V[0],Vrest[i],DV=DV)
                    Vrest[i] = EstimateVrest(i,2,poly,p[i],V[nv-1],Vrest[i],DV=DV)
                else:
                    p1,p2 = polyparas(p[i],poly)
                    Vrest[i] = EstimateVrest(i,1,'1',p1,V[0],Vrest[i])
                    Vrest[i] = EstimateVrest(i,2,'2',p2,V[nv-1]-p[0],Vrest[i])
                if print_warnings == 'yes':
                    if len(Vrest[i]) == 0:
                        print("WARNING: Unable to estimate Vrest at t = "+str(t[i])+" ms.")
                        #Vrest[i] = [V[0]]
                        #cont = input('Continue (y/n; y => cd = 0)? ')
                        #if cont == 'n': sys.exit()
                    else:
                        print("WARNING: Apparently I*(V) doesn't span zero.")
                        print("         Estimating Vrest[i] by extrapolation.")
        nVrest.append([]); nVrest[i] = len(Vrest[i]); Vrest[i].sort()
        if nVrest[i] == 1:
            cdt.append(t[i])
            cd.append([]); j = 0
            V1 = V[0]; V2 = V[nv-1]
            Vj = []; ii = 0
            while ii < nv:
                if V1 <= V[ii] and V[ii] <= V2:
                    Vj.append(V[ii])
                ii = ii + 1
            Vj = np.array(Vj)
            cdj = 0.1*solveODE(t[i],Vj,Vrest[i][j],A,gamma,DV,p[i],poly,Istar0,bL,V[0],options,print_warnings)  #pA/um^2 -> mA/cm^2
            cd[i] = np.concatenate((cd[i],cdj))
            if len(cd[i]) != nv:
                cdt[i] = -cdt[i]
                cd[i] = np.zeros(nv)
                nduds = nduds + 1
        else:
            cd.append(np.zeros(nv))
            cdt.append(-t[i])
            nduds = nduds + 1
        i = i + 1
    cd = np.array(cd)
    if nduds > 0:
        i = 1; i1 = 0
        while i < n:
            if cdt[i] < 0:
                if i1 == 0: i1 = i
            if cdt[i] > 0 and i1 > 0:
                j = i1
                while j < i:
                    cdt[j] = -cdt[j]
                    j = j + 1
                ij = 0
                while ij < nv:
                    b = (cd[i,ij]-cd[i1-1,ij])/(cdt[i]-cdt[i1-1])
                    j = i1
                    while j < i:
                        cd[j,ij] = cd[i1-1,ij] + b*(cdt[j]-cdt[i1-1])
                        j = j + 1
                    ij = ij + 1
                i1 = 0
            i = i + 1
        if i1 > 0:
            j = i1
            while j < n:
                cdt[j] = -cdt[j]
                j = j + 1
            ij = 0
            while ij < nv:
                j = i1
                while j < n:
                    cd[j,ij] = cd[i1-1,ij]
                    j = j + 1
                ij = ij + 1
    if avint > 0: 
            dt = t[1]-t[0]; nav0 = int(avint/dt)
            i = 0
            while i < nv:
                cd[:,i] = MoveAv(cd[:,i],nav0)
                i = i + 1
    i = 0
    if cdL_method == 3:
        VL,cdL = load_xy('cdL.txt',0,1)
        if max(VL) < max(V) or min(VL) > min(V):
            try:
                sys.exit()
            except SystemExit:
                print('Error in cdL.txt:')
                print('max(V) < max(Vcmnd) and/or min(V) > min(Vcmnd)')
        else:
            p = intp.interp1d(VL,cdL,fill_value='extrapolate')
            print(p)
        cdL = np.zeros(nv); cdL = p(V); 
        while i < nv:
            cd[:,i] = cd[:,i] - cdL[i]
            i = i + 1
    elif cdL_method == 2:
        cdL = cd[0,:].copy(); p = np.polyfit(V,cdL,1)
        while i < nv:
            cd[:,i] = cd[:,i] - np.polyval(p,V[i])
            i = i + 1
    elif cdL_method == 1:
        cdL = np.zeros(nv); 
        while i < nv:
            cdL[i] = cd[0,i]
            cd[:,i] = cd[:,i] - cdL[i]
            i = i + 1
    elif cdL_method == 0:
        file = open('cdL_paras.txt','r')
        cdL_paras = file.readlines(); file.close()
        s = cdL_paras[0].split(); gL = float(s[1])
        s = cdL_paras[1].split(); EL = float(s[1])
        cdL = np.zeros(nv); 
        while i < nv:
            cdL[i] = gL*(V[i] - EL)
            cd[:,i] = cd[:,i] - cdL[i]
            i = i + 1
    if rescdfile != 'none': 
        rest, rescd = load_tVI('cdn_blocked.txt')
        rescd = np.insert(rescd,0,0,axis=1)
        i = 0
        while i < nv:
            p = intp.PchipInterpolator(rest,rescd[:,i],extrapolate=True)
            cd[:,i] = cd[:,i] - p(t)
            i = i + 1
    
    if k > 0:
        j = 0
        while j < nv:
            linterpf = open(coxdir+'/linterp_'+str(Vcmnd[j])+'_'+str(k)+'.txt','w')
            linterpf.write('%10s'%'linterp'+'%15s'%'x1'+'%15s'%'fx1'+'%15s'%'x2'+'%15s'%'fx2'+'%15s'%'fsave'+'%15s'%'F1'+'%15s'%'F2'+'\r')
            i = 0
            while i < n:
                linterpf.write('%10d'%linterp[i,j]+'%15e'%x1[i,j]+'%15e'%fx1[i,j]+'%15e'%x2[i,j]+'%15e'%fx2[i,j]+'%15e'%fsave[i,j]+'%15e'%F1[i,j]+'%15e'%F2[i,j]+'\r')
                i = i + 1
            linterpf.close()
            j = j + 1
    else:
        file = open('IholdVholdVcrctVrestSDI.txt','a')
        file.write('Vrest(mV): %7.2f'%min(Vrest[n-1])+'\r')
        file.write('SD(I)(pA): %13.5e'%SDtol+'\r')
        file.close()
    result['t (ms)'] = t; result['cd (mA/cm^2)'] = cd
    result['cdL (mA/cm^2)'] = cdL
    cd = np.delete(cd,0,1); Vcmnd = np.delete(Vcmnd,0,0)
    save_tVI('cd.txt',t,Vcmnd,cd,'i(mA/cm^2)')
    shutil.copy('cd.txt', coxdir+'/cd_'+str(k)+'.txt')
    os.chdir(cwd)
    return result
    
def CorrectCoxVpulse(parameter_file,tbreak=[],Area=0,Ra=100,t=[],V=[],I=[],diam=[],Raccess=0, 
                    Rseal=np.Inf,LJP=0.0,poly=[5,4.0], DV=0.1, Iunit='pA', MinErrorStop = 'yes', 
                    V_LJP_corrected='yes', data_lw=5.0, outputdir='output', cwd = os.getcwd(),
                    tDIfile='', flagfile='flag.txt', coxdir='CorrectCoxVramp', taum_mult = 5.0, 
                    do_plots='no', maxit=9, maxIerror_tol=1.0, kstart = 0, delim = '', 
                    Icap_error_tol=0.1, VRm=[], options = {}, saveCox = 'no', skip = 0, 
                    criterion = 'I&Icap', gLfrac = 0.01, color=['0.6','0.8'], cdL_method = 1):
    
    plt.close('all'); plt.ion; user_paras = []; neuron_path = ''
    try:
        file = open('user_parameters.txt','r')
        user_paras = file.readlines(); file.close()
    except (FileNotFoundError,IndexError):
        pass
    file = open(parameter_file,'r')
    data = file.readlines(); file.close()
    blank = 0; constrain_cd = 'no'; i = 0
    while i < len(data):
        data[i] = data[i].strip('\n')
        v = data[i].split(':')
        if len(v) > 2:
            j = 2
            while j < len(v):
                v[1] = v[1] + ':'+v[j]
                j = j + 1
        v[1] = v[1].strip()
        if len(v[1]) > 0:
            if v[0] == 'neuron_path': neuron_path  = v[1]
            if v[0] == 'neuron_file': neuron_file = v[1]
            if v[0] == 'Stop_on_minimum_RMS_error': MinErrorStop = v[1]
            if v[0] == 'Leak-subtracted_currents_in_file': tDIfile = v[1]
            if v[0] == 'Method_for_estimating_the_leak_current_density_iL_(0-3)': cdL_method = int(v[1])
            if v[0] == 'Iunit': Iunit = v[1]
            if v[0] == 'tunit': tunit = v[1]
            if v[0] == 'Data_delimeter': 
                delim = v[1]
                if delim == 'tab': delim = '\t'
                if delim == 'space': delim = ''
            if v[0] == 'Number_of_header_lines_to_skip_(excluding_column_names)': skip = int(v[1])
            if v[0] == 'Fit_functions_for_i(t,V)_in_file': funcfile = v[1]
            if v[0] == 'Print_parameter_estimates_(yes/no)': print_paras = v[1]
            if v[0] == 'Add_this_ad_hoc_function_to_i(t,V)': adhocfunc = v[1]
            if v[0] == 'Model_parameter_file_for_blocked_condition': rescdfile = v[1]
            if v[0] == 'Exclude_this_initial_interval_(ms)_from_the_fit': blank = float(v[1])
            if v[0] == 'Constrain_i(t,V)_to_be_positive': constrain_cd = v[1]
            if v[0] == 'maxit': maxit = int(v[1])
            if v[0] == 'coxdir': coxdir = v[1]
            if v[0] == 'outputdir': outputdir = v[1]
            if v[0] == 'Raccess(MOhm)': Raccess = float(v[1])
            if v[0] == 'Vhold(mV)': Vhold0 = float(v[1]) 
            if v[0] == 'Vcmnd(mV)': 
                v = v[1].split()
                Vcmnd = []; j = 0
                while j < len(v):
                    Vcmnd.append(float(v[j]))
                    j = j + 1
                Vcmnd = np.array(Vcmnd)
                Vcmnd0 = np.copy(Vcmnd)
                Vcmnd0 = np.insert(Vcmnd0,0,Vhold0,axis=0)
        i = i + 1
    if kstart == 0:
        try:
            os.chdir(outputdir)
            os.chdir(cwd)
            shutil.rmtree(outputdir, ignore_errors=True)
            os.rmdir(outputdir)
            os.mkdir(outputdir)
        except FileNotFoundError:
            os.mkdir(outputdir)
    else:
        kstart = kstart + 1
    os.chdir(cwd)
    outputdir = outputdir+'/'
    print('\r')
    
    if maxit <= kstart: maxit = kstart + 1
    t0 = time.time(); k0 = kstart; 
    ok = 1; k = kstart; minSD = -1
    while k <= maxit:
        if k == 0 and rescdfile != 'none':
            file = open('parameter_file.txt','w')
            file.write(parameter_file+'\n')
            file.write('Blocked: 0\n')
            file.close()            
            delete_file(flagfile); flag = ''
            if len(neuron_path) == 0:
                sb.run('neuron.exe '+neuron_file)
            else:
                sb.run(neuron_path+'/neuron.exe '+neuron_file)
            while len(flag) == 0:
                try:
                    file = open(flagfile,'r')
                    data = file.readlines()
                    flag = data[0]
                    file.close()
                except (FileNotFoundError,IndexError):
                    pass
            
        result = CorrectVpulse(k, tbreak=tbreak, d=diam, A=Area, Ra=Ra, 
                        Raccess=Raccess, Rseal=Rseal, LJP=LJP, ok = ok, 
                        t=t, V=V, I=I, Iunit='pA', V_LJP_corrected = 'yes',  
                        poly=poly, DV=DV, data_lw = 5.0, cwd = cwd, minSD = minSD, 
                        color=['0.6','0.8'], coxdir=coxdir, maxit=maxit,  
                        do_plots=do_plots, tDIfile='', flagfile=flagfile, 
                        options = options, parameter_file = parameter_file, 
                        criterion = criterion, maxIerror_tol = maxIerror_tol)
        file = open('parameter_file.txt','w')
        file.write(parameter_file+'\n')
        file.write('Iteration: '+str(k)+'\n')
        file.close()
        file = open('IholdVholdVcrctVrestSDI.txt','r')
        data = file.readlines(); file.close()
        v = data[2].strip('\n'); v = v.split(':')
        v = v[1].split(); V = []; i = 0
        while i < len(v):
            V.append(float(v[i]))
            i = i + 1
        v = data[1].strip('\n'); v = v.split(':')
        Vhold = float(v[1]); V = np.array(V)
        V = np.insert(V,0,Vhold,axis=0); nv = len(V)
        v = data[4].strip('\n'); v = v.split(':')
        SDtol = float(v[1])
        if k > 0:
            runtime = time.time()-t0
            SD = result['RMS error (pA)']
            print('')
            print('     Iteration: ',k-1)
            print('  Run time (s): %5.1f'%runtime)            
            print('RMS error (pA): %11.3e'%SD)
            print('\r')
            if k == 1:
                printfile = open('printout.txt','w')
            else:
                printfile = open('printout.txt','a')
            print('     Iteration: ',k-1,file=printfile)
            print('  Run time (s): %5.1f'%runtime,file=printfile)
            print('RMS error (pA): %11.3e'%SD,file=printfile)
            print('',file=printfile)
            printfile.close()
            if k == 1 or k == kstart:
                minSD = SD
                k0 = 0
            else:
                if minSD > SD:
                    minSD = SD
                    k0 = k-1
            if SD <= SDtol or (MinErrorStop == 'yes' and minSD < SD): break
        if ok == -1: break
        
        print('')
        print('Fitting functions to i(t,V)')
        ok = 0
        while ok == 0:
            f = open(funcfile, 'r'); l = f.readlines(); file.close()
            i = 0
            while i < len(l):
                if 'func.' in l[i]: break
                l[i] = l[i].strip('\n')
                v = l[i].split(':')
                if len(v) > 1:
                    v[1] = v[1].strip()
                    #if v[0]  == 'Full_model': fullmodel = v[1]
                    if v[0]  == 'k': power = int(v[1])
                    if v[0]  == 'Erev(mV)': Erev = float(v[1])
                    if 'taum1_extrapolation_(low_V)' in v[0]: taum1_extrap_low = v[1]
                    if 'taum1_low_V_(ms)' in v[0]: taum1_low_V = float(v[1])
                    if 'taum1_extrapolation_(high_V)' in v[0]: taum1_extrap_high = v[1]
                    if 'taum1_high_V_(ms)' in v[0]: taum1_high_V = float(v[1])
                    if 'taum2_extrapolation_(low_V)' in v[0]: taum2_extrap_low = v[1]
                    if 'taum2_low_V_(ms)' in v[0]: taum2_low_V = float(v[1])
                    if 'taum2_extrapolation_(high_V)' in v[0]: taum2_extrap_high = v[1]
                    if 'taum2_high_V_(ms)' in v[0]: taum2_high_V = float(v[1])
                    if 'taum3_extrapolation_(low_V)' in v[0]: taum3_extrap_low = v[1]
                    if 'taum3_low_V_(ms)' in v[0]: taum3_low_V = float(v[1])
                    if 'taum3_extrapolation_(high_V)' in v[0]: taum3_extrap_high = v[1]
                    if 'taum3_high_V_(ms)' in v[0]: taum3_high_V = float(v[1])
                    if 'tauh1_extrapolation_(low_V)' in v[0]: tauh1_extrap_low = v[1]
                    if 'tauh1_low_V_(ms)' in v[0]: tauh1_low_V = float(v[1])
                    if 'tauh1_extrapolation_(high_V)' in v[0]: tauh1_extrap_high = v[1]
                    if 'tauh1_high_V_(ms)' in v[0]: tauh1_high_V = float(v[1])
                    if 'tauh2_extrapolation_(low_V)' in v[0]: tauh2_extrap_low = v[1]
                    if 'tauh2_low_V_(ms)' in v[0]: tauh2_low_V = float(v[1])
                    if 'tauh2_extrapolation_(high_V)' in v[0]: tauh2_extrap_high = v[1]
                    if 'tauh2_high_V_(ms)' in v[0]: tauh2_high_V = float(v[1])
                i = i + 1
            i = i + 1
            func = ['0']; func_paras = ['']; 
            paran = [[]]; parav = [[]]; ij = 0
            while i < len(l):
                if len(l[i]) > 1:
                    paran.append([]); parav.append([])
                    ij = ij + 1
                    l[i] = l[i].strip('\n')
                    v = l[i].split()
                    func.append(v[1])
                    func_paras.append(function_parameters(rescdfile,v[1],user_paras))
                    if len(v) > 2:
                        j = 2
                        while j < len(v):
                            paran[ij].append(v[j])
                            parav[ij].append(float(v[j+1]))
                            j = j + 2
                i = i + 1
            npmax = len(func_paras[0])
            fullmodel = func[0]; i = 1
            while i < len(func_paras):
                if len(func_paras[i]) > npmax: 
                    npmax = len(func_paras[i])
                    fullmodel = func[i]
                i = i + 1
            if fullmodel == '0+A' or fullmodel == 'A^k+L': fullmodel = 'A^k+A'
            if fullmodel == '0+A+L': fullmodel = 'A^k+A+L'
                
            t = result['t (ms)'].copy()
            taumb = taum_mult*t[len(t)-1]
            if '#' not in fullmodel:
                if fullmodel == 'A^k': 
                    paratable = np.zeros([nv,2])
                    paranames = ['i1inf(mA/cm2)','taum1(ms)']
                elif fullmodel == 'A^k+A' or fullmodel == '0+A' or fullmodel == 'A^k+L': 
                    paratable = np.zeros([nv,4])
                    paranames = ['i1inf(mA/cm2)','taum1(ms)','i2inf(mA/cm2)','taum2(ms)']
                    if 'L' in fullmodel:
                        taumb = taum_mult*t[len(t)-1]; i = 0
                        while i < nv:                          
                            paratable[i,3] = taumb
                            i = i + 1
                elif fullmodel == '(A^k)A': 
                    paratable = np.zeros([nv,3])
                    paranames = ['i1inf(mA/cm2)','taum1a(ms)','taum1b(ms)']
                elif fullmodel == '(A^k)A+L': 
                    paratable = np.zeros([nv,5])
                    paranames = ['i1inf(mA/cm2)','taum1a(ms)','taum1b(ms)','i2inf(mA/cm2)','taum2(ms)']
                    taumb = taum_mult*t[len(t)-1]; i = 0
                    while i < nv:  
                        if 'L' in func[i]: paratable[i,4] = taumb
                        i = i + 1
                elif fullmodel == 'A^k+A+L'or fullmodel == '0+A+L': 
                    paratable = np.zeros([nv,6])
                    paranames = ['i1inf(mA/cm2)','taum1(ms)','i2inf(mA/cm2)','taum2(ms)','i3inf(mA/cm2)','taum3(ms)']
                    taumb = taum_mult*t[len(t)-1]; i = 0
                    while i < nv:                          
                        if 'L' in func[i]: paratable[i,5] = taumb
                        i = i + 1
                elif fullmodel == '(A^k)Ia' or fullmodel == '(A^k)Ib' or fullmodel == '(A^k)Ic': 
                    paratable = np.zeros([nv,4]); i = 0
                    while i < nv:
                        if 'a' in func[i] or 'b' in func[i]:
                            paratable[i,3] = 0
                        else:
                            paratable[i,3] = 1
                        i = i + 1
                    paranames = ['i1inf(mA/cm2)','taum1(ms)','tauh1(ms)','h1inf']
                elif '(A^k)II' in fullmodel:
                    paratable = np.zeros([nv,6]); i = 0
                    while i < nv:
                        if 'd' in func[i] or 'e' in func[i]:
                            paratable[i,5] = 0
                        else:
                            paratable[i,5] = 1
                        if 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                            paratable[i,3] = 0
                        else:
                            paratable[i,3] = 1
                        i = i + 1
                    paranames = ['i1inf(mA/cm2)','taum1(ms)','tauh1(ms)','h1inf','tauh2(ms)','h2inf']
            else:
                paranames = uf.function_parameters(rescdfile,fullmodel,user_paras)
                paratable = np.zeros([nv,len(paranames)])
                
            cd = result['cd (mA/cm^2)'].copy()
            cdL = result['cdL (mA/cm^2)'].copy()
            if cdL_method > 0 and cdL_method < 3:
                p = np.polyfit(V,cdL,1); gL = p[0]; EL = -p[1]/p[0]
                cdLfit = np.zeros(len(V)); i = 0
                while i < len(V):
                    cdLfit[i] = gL*(V[i] - EL)
                    i = i + 1                                
            cdfunc = np.zeros([1000,nv]); tfunc = np.zeros(1000)
            n = len(t); Dt = t[n-1]-t[0]; dt = Dt/999; i = 0
            while i < 1000:
                tfunc[i] = i*dt
                i = i + 1
            if blank > 0:
                i = 0
                while i < n:
                    if t[i] >= blank: break
                    i = i + 1
                cdfit = np.delete(cd,np.s_[1:i],0)
                tfit = np.delete(t,np.s_[1:i],0)
            else:
                cdfit = np.copy(cd)
                tfit = np.copy(t)

            i = 0
            while i < nv:
                if i == 0:
                    print('%5.1f'%Vhold0, ' mV')
                else:
                    print('%5.1f'%Vcmnd[i-1], ' mV')
                if constrain_cd == 'yes':
                    j = 0
                    while j < len(cd):
                        if cd[j,i] < 0: cd[j,i] = 0
                        j = j + 1
                    j = 0
                    while j < len(cdfit):
                        if cdfit[j,i] < 0: cdfit[j,i] = 0
                        j = j + 1
                p0 = ini_paras(rescdfile,tfit,cdfit[:,i],func[i],power,V[i],adhocfunc,user_paras)
                if len(p0) > 0:
                    if len(paran[i]) > 0:
                        kk = 0
                        while kk < len(paran[i]):
                            jk = func_paras[i].index(paran[i][kk])
                            p0[jk] = parav[i][kk]
                            kk = kk + 1

                    if print_paras == 'yes': print('Initial parameter estimates: ',p0)
                    try:
                        res = op.least_squares(iresids, p0, args = (rescdfile,tfit,cdfit[:,i],func[i],power,V[i],adhocfunc,user_paras))
                        fiterror = 0
                    except:
                        print('')
                        print('Problem with fiting at V = '+'%5.1f'%Vcmnd[i-1]+' mV\r')
                        print('Initial parameter estimates: ',p0)
                        print('Plotting the offending current density and exiting.')
                        print('')
                        fig = plt.figure()
                        ax = fig.add_subplot(111)
                        plt.plot(tfit,cdfit[:,i],linewidth=1.0,color='b')
                        plt.xlabel('$t$ (ms)')
                        plt.ylabel('$i$ (mA cm$^{\minus2}$)')
                        plt.title('k = '+str(k)+': Problem with fiting at V = '+'%5.1f'%Vcmnd[i-1]+' mV')
                        fiterror = i
                        break
                    p = res.x; j = 0
                    if print_paras == 'yes': print('Final parameter estimates: ',p)

                    while j < 1000:
                        cdfunc[j,i] = it(rescdfile,p,tfunc[j],func[i],power,V[i],adhocfunc,user_paras)
                        j = j + 1
                    nparas = len(func_paras[i]); j = 0
                    while j < nparas:
                        if 'L' in func[i] and '0+' not in func[i] and func_paras[i][j] == 'b':
                            paratable[i,j] = p[j]*taumb   #i2inf
                            paratable[i,j+1] = taumb
                        elif '0+' in func[i]:
                            if 'L' in func[i] and func_paras[i][j] == 'b':
                                paratable[i,j+2] = p[j]*taumb
                                paratable[i,j+3] = taumb
                            else:
                                paratable[i,j+2] = p[j]
                            if j < 2: paratable[i,j] = 0
                        elif 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                            if j > 2: 
                                paratable[i,j+1] = p[j]
                            else:
                                paratable[i,j] = p[j]
                        else:
                            paratable[i,j] = p[j]
                        if 'I' in func[i] and func_paras[i][j] == 'b':
                            if 'Ib' in func[i]:
                                paratable[i,j] = 1/p[j]   #tauh
                            else:
                                paratable[i,j+1] = 1/p[j]   #tauh
                        j = j + 1
                    if func[i] == '(A^k)Ia' or func[i] == '(A^k)Ib' or 'd' in func[i] or 'e' in func[i] or 'f' in func[i]:
                        paratable[i,3] = 0
                    if func[i] == '(A^k)IIa' or func[i] == '(A^k)IIb' or 'd' in func[i] or 'e' in func[i]:
                        paratable[i,5] = 0                    
                else:
                    cdfunc[:,i] = 0
                i = i + 1
            
            if fiterror == 0:
                if cdL_method > 0:
                    file = open('cdL_paras.txt','w')
                    if cdL_method < 3:
                        file.write('gL(S/cm^2): %15e'%gL+'\r')
                        file.write('    EL(mV): %6.1f'%EL+'\r')
                    elif cdL_method == 3:
                        file.write('iL(V) is user-specified in cdL.txt.\r')
                    file.close()
                if do_plots == 'yes':
                    kk = 0
                    while kk < nv:
                        if kk == 0:
                            fig = plt.figure()
                            ax = fig.add_subplot(111)
                        #plt.plot(t,cd[:,kk],linewidth=1.0,color='b')
                        plt.plot(tfit,cdfit[:,kk],linewidth=1.0,color='b')
                        plt.plot(tfunc,cdfunc[:,kk],'k-',linewidth=1.0)
                        kk = kk + 1
                    plt.xlabel('$t$ (ms)')
                    plt.ylabel('$i$ (mA cm$^{\minus2}$)')
                    plt.title('k = '+str(k)+': Currents densities with fitted curves')
                cdfunc = np.delete(cdfunc,0,1)
                save_tVI('cd_fit.txt',tfunc,Vcmnd,cdfunc,'i(mA/cm^2)')
                shutil.copy('cd_fit.txt', coxdir+'/cd_fit_'+str(k)+'.txt')
            
                if 'I' not in fullmodel:
                    paratable[:,1] = impute_tau(fullmodel,V,paratable[:,1],taum1_extrap_low,taum1_low_V,taum1_extrap_high,taum1_high_V)
                    if 'A^k+A' in fullmodel:
                        paratable[:,3] = impute_tau(fullmodel,V,paratable[:,3],taum2_extrap_low,taum2_low_V,taum2_extrap_high,taum2_high_V)
                        if 'L' in fullmodel:
                            paratable[:,5] = impute_tau(fullmodel,V,paratable[:,5],taum3_extrap_low,taum3_low_V,taum3_extrap_high,taum3_high_V)
                    if '(A^k)A' in fullmodel:
                        paratable[:,2] = impute_tau(fullmodel,V,paratable[:,2],taum2_extrap_low,taum2_low_V,taum2_extrap_high,taum2_high_V)
                        if 'L' in fullmodel:
                            paratable[:,4] = impute_tau(fullmodel,V,paratable[:,4],taum3_extrap_low,taum3_low_V,taum3_extrap_high,taum3_high_V)
                else:
                    paratable[:,1] = impute_tau(fullmodel,V,paratable[:,1],taum1_extrap_low,taum1_low_V,taum1_extrap_high,taum1_high_V)
                    paratable[:,2] = impute_tau(fullmodel,V,paratable[:,2],tauh1_extrap_low,tauh1_low_V,tauh1_extrap_high,tauh1_high_V)
                    if 'tauh2(ms)' in paranames:
                        paratable[:,4] = impute_tau(fullmodel,V,paratable[:,4],tauh2_extrap_low,tauh2_low_V,tauh2_extrap_high,tauh2_high_V)
                paratable = uf.parameter_table(rescdfile,V,func,paranames,paratable,user_paras)
    
                logtauh = 0
                if 'II' in fullmodel:
                    tauh1max = np.max(paratable[:,2])
                    tauh2max = np.max(paratable[:,4])
                    if tauh1max > 0 and tauh2max > 0:
                        if tauh1max/tauh2max < 0.1: logtauh = 1
                        if tauh1max/tauh2max > 10: logtauh = 1
                if do_plots == 'yes':
                    if fullmodel == 'A^k':
                        fig, axs = plt.subplots(2, 1, sharex='all')
                        axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
                        axs[0].plot(V,cdL,'b-o',linewidth=1.0)
                        axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
                        axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
                        axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
                        axs[1].set_xlabel('$V$ (mV)')
                        axs[1].set_ylabel('${\\tau}m1$ (ms)')
                    elif '(A^k)A' in fullmodel:
                        fig, axs = plt.subplots(2, 1, sharex='all')
                        axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
                        axs[0].plot(V,cdL,'b-o',linewidth=1.0)
                        axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
                        axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
                        axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
                        axs[1].plot(V,paratable[:,2],'b-o',linewidth=1.0)
                        axs[1].legend(['${\\tau}m1a$','${\\tau}m1b$'], title='ms', fontsize=10)                        
                        axs[1].set_xlabel('$V$ (mV)')
                        axs[1].set_ylabel('${\\tau}m$ (ms)')
                    elif 'A^k+' in fullmodel: 
                        fig, axs = plt.subplots(2, 2, sharex='all')
                        axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
                        axs[0,0].plot(V,cdL,'b-o',linewidth=1.0)
                        axs[0,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
                        axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
                        axs[1,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
                        axs[1,0].set_xlabel('$V$ (mV)')
                        axs[1,1].set_xlabel('$V$ (mV)')
                        axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
                        axs[0,1].text(0.1, 0.97, '$   i2\infty$\nmA cm$^{\minus2}$', transform=axs[0,1].transAxes, verticalalignment='top')
                        axs[1,0].text(0.95, 0.95, '${\\tau}m1$\n(ms)', transform=axs[1,0].transAxes, verticalalignment='top')
                        axs[1,1].text(0.8, 0.97, '${\\tau}m2$\n(ms)', transform=axs[1,1].transAxes, verticalalignment='top')
                    else:
                        fig, axs = plt.subplots(2, 2, sharex='all')
                        axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
                        axs[0,0].plot(V,cdL,'b-o',linewidth=1.0)
                        axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
                        axs[0,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
                        if logtauh == 1:
                            axs[1,1].semilogy(V,paratable[:,2],'k-o',linewidth=1.0)
                        else:
                            axs[1,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
                        axs[1,0].set_xlabel('$V$ (mV)')
                        axs[1,1].set_xlabel('$V$ (mV)')
                        axs[1,0].text(0.38, 0.43, '${\\tau}m1$\n(ms)', transform=axs[1,0].transAxes, verticalalignment='top')
                        axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')
                        if 'II' not in fullmodel:
                            axs[0,1].text(0.01, 0.05, '$h1\infty$', transform=axs[0,1].transAxes, verticalalignment='top')
                            axs[1,1].text(0.01, 0.25, '${\\tau}h1$\n(ms)', transform=axs[1,1].transAxes, verticalalignment='top')
                        else:
                            axs[0,1].plot(V,paratable[:,5],'b-o',linewidth=1.0)
                            axs[0,1].legend(['$h1$','$h2$'], title='$h\infty$', fontsize=10)                        
                            if logtauh == 1:
                                axs[1,1].semilogy(V,paratable[:,4],'b-o',linewidth=1.0)
                            else:
                                axs[1,1].plot(V,paratable[:,4],'b-o',linewidth=1.0)
                            axs[1,1].legend(['$h1$','$h2$'], title='${\\tau}h$ (ms)', fontsize=10)
                    fig.suptitle('k = '+str(k)+': Parameter estimates from fitted i(t,V) curves')
                
                file = open('cdn_paras.txt','w')
                file.write(fullmodel+'  k = '+str(power)+'  Erev(mV) = '+str(Erev)+'\n')
                file.write('%8s'%'V(mV)'); i = 0
                while i < len(paranames):
                    file.write('%15s'%paranames[i])
                    i = i + 1
                file.write('\n')
                i = 0
                while i < nv:
                    #file.write('%8.1f'%V[i])
                    file.write('%8.1f'%Vcmnd0[i])
                    j = 0
                    while j < len(paranames):
                        file.write('%15e'%paratable[i,j])
                        j = j + 1
                    file.write('\n')
                    i = i + 1
                file.close()
                shutil.copy('cdn_paras.txt', coxdir+'/cdn_'+str(k)+'_paras.txt')
                file = open('cdL.txt','w'); i = 0
                file.write('%8s'%'V(mV)'+'%15s'%'iL(mA/cm^2)')
                if cdL_method > 0 and cdL_method < 3:
                    file.write('%20s'%'iL_fit(mA/cm^2)'+'\r')
                else:
                    file.write('\r')
                while i < nv:
                    file.write('%8.1f'%V[i]+'%15e'%cdL[i])
                    if cdL_method > 0 and cdL_method < 3:
                        file.write('%20e'%cdLfit[i]+'\r')
                    else:
                        file.write('\r')
                    i = i + 1
                file.close()
                shutil.copy('cdL.txt', coxdir+'/cdL_'+str(k)+'.txt')
                shutil.copy('cdL_paras.txt', coxdir+'/cdL_'+str(k)+'_paras.txt')
                fn = funcfile.replace('.txt','_'+str(k)+'.txt')
                shutil.copy(funcfile, coxdir+'/'+fn)
                
                delete_file(flagfile); flag = ''
                if len(neuron_path) == 0:
                    sb.run('neuron.exe '+neuron_file)
                else:
                    sb.run(neuron_path+'/neuron.exe '+neuron_file)
                while len(flag) == 0:
                    try:
                        file = open(flagfile,'r')
                        data = file.readlines()
                        flag = data[0]
                        ok = int(data[0])
                        file.close()
                    except (FileNotFoundError,IndexError):
                        pass
            else:
                if k > 0: 
                    os.chdir(coxdir)
                    filek0 = 'cd_'+str(k0)+'.txt'; file = 'cd.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'cd_fit_'+str(k0)+'.txt'; file = 'cd_fit.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'cdn_'+str(k0)+'_paras.txt'; file = 'cdn_paras.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'cdL_'+str(k0)+'.txt'; file = 'cdL.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'cdL_'+str(k0)+'_paras.txt'; file = 'cdL_paras.txt'
                    shutil.copy(filek0, '../'+file)
                    try:
                        filek0 = 'cdn_'+str(k0)+'.txt'; file = 'cdn.txt'
                        shutil.copy(filek0, '../'+file)
                    except FileNotFoundError:
                        pass
                    filek0 = 'Ierror_'+str(k0)+'.txt'; file = 'Ierror.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'Ihold_DI_'+str(k0)+'.txt'; file = 'Ihold_DI.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'tDIpred_'+str(k0)+'.txt'; file = 'tDIpred.txt'
                    shutil.copy(filek0, '../'+file)
                    filek0 = 'Iresids_'+str(k0)+'.txt'; file = 'Iresids.txt'
                    shutil.copy(filek0, '../'+file)
                    os.chdir(cwd)
                    break
                else:
                    print('Iteration 0: Estimation of i(V,t) failed.')
                    break
        if fiterror > 0: break
        k = k + 1
    if k > 0:
        print('\r')
        print('The smallest RMS error was obtained with iteration '+str(k0)+'.')
        print('\r')
        printfile = open('printout.txt','a')
        print('\r',file=printfile)
        print('The smallest RMS error was obtained with iteration '+str(k0)+'.',file=printfile)
        print('\r',file=printfile)
        if fiterror > 0:
            print('Fitting failed for iteration '+str(k0+1)+' at V = '+'%5.1f'%Vcmnd[fiterror-1]+' mV',file=printfile)
            print('\r',file=printfile)
        printfile.close()
    
        os.chdir(coxdir)
        file = funcfile.replace('.txt','_'+str(k0)+'.txt')
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'cd_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'cd_fit_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'cdn_'+str(k0)+'_paras.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'cdL_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'cdL_'+str(k0)+'_paras.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        try:
            file = 'cdn_'+str(k0)+'.txt'
            shutil.copy(file, '../'+outputdir+'/'+file)
        except FileNotFoundError:
            pass
        file = 'Ierror_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'Ihold_DI_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'tDIpred_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        file = 'Iresids_'+str(k0)+'.txt'
        shutil.copy(file, '../'+outputdir+'/'+file)
        os.chdir(cwd)
        if '/' in rescdfile:
            os.chdir(outputdir)
            s = rescdfile.split('/')
            blocked_dir = s[0]; kk = 1
            while kk < len(s)-1:
                blocked_dir = blocked_dir + '/' + s[kk]
                kk = kk + 1
            os.mkdir(blocked_dir)
            os.chdir(cwd)
        shutil.copy('printout.txt', outputdir+'/'+'printout.txt')
        shutil.copy(parameter_file, outputdir+'/'+parameter_file)
        shutil.copy(tDIfile, outputdir+'/') #+tDIfile
        shutil.copy('Crct_tDI.txt', outputdir+'/Crct_tDI.txt')
        shutil.copy('Raw_tDI.txt', outputdir+'/Raw_tDI.txt')
        shutil.copy('Crct_tV.txt', outputdir+'/Crct_tV.txt')
        shutil.copy('IholdVholdVcrctVrestSDI.txt', outputdir+'/'+'IholdVholdVcrctVrestSDI.txt')
        if rescdfile != 'none':
            shutil.copy('cdn_blocked.txt', outputdir+'/cdn_blocked.txt')
            shutil.copy(rescdfile, outputdir+'/'+rescdfile)
        if len(user_paras) > 0:
            shutil.copy('user_parameters.txt', outputdir+'/user_parameters.txt')
        if saveCox == 'yes': 
            shutil.rmtree(outputdir+'/'+coxdir, ignore_errors=True)
            shutil.copytree(coxdir, outputdir+'/'+coxdir)
        
        tp,predI = load_tVI(outputdir+'/'+'tDIpred_'+str(k0)+'.txt')
        obst,obsI = load_tVI(tDIfile,skip=skip,delim=delim)
        if Iunit != 'pA': obsI = 1000*obsI  #nA -> pA
        if tunit != 'ms': obst = 1000*obst  #s -> ms
        nv = nv - 1; kk = 0
        while kk < nv:
            if kk == 0:
                fig = plt.figure()
                ax = fig.add_subplot(111)
            plt.plot(obst,obsI[:,kk],linewidth=0.5,color='0.6')
            plt.plot(tp,predI[:,kk],'k-',linewidth=1.0)
            kk = kk + 1
        plt.xlabel('$t$ (ms)')
        plt.ylabel('$I$ (pA)')
        legend = ['Observed $I$','Predicted $I$']
        plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
        plt.title('k = '+str(k0)+': Leak-subtracted currents predicted by the model')
        plt.savefig(outputdir+'/I.png',dpi=600)
        
        file = open('parameter_file.txt','w')
        file.write(parameter_file+'\n')
        file.write('Best_iteration: '+str(k0)+'\n')
        file.close()
        shutil.copy('parameter_file.txt', outputdir+'/parameter_file.txt')
        if k0 > 0:
            delete_file(flagfile); flag = ''
            if len(neuron_path) == 0:
                sb.run('neuron.exe '+neuron_file)
            else:
                sb.run(neuron_path+'/neuron.exe '+neuron_file)
            while len(flag) == 0:
                try:
                    file = open(flagfile,'r')
                    data = file.readlines()
                    flag = data[0]
                    file.close()
                except (FileNotFoundError,IndexError):
                    pass
            
            t,cd = load_tVI(outputdir+'/'+'cd_'+str(k0)+'.txt')
            cdnt,cdn = load_tVI(outputdir+'/'+'cdn_'+str(k0)+'_Raccess=0.txt')
            p = intp.PchipInterpolator(cdnt,cdn,extrapolate=True)
            cdn = np.zeros(n); cdn = p(t); cdnt = t.copy()
            if blank > 0:
                i = 0
                while i < len(t):
                    if t[i] >= blank: break
                    i = i + 1
                cdnplot = np.delete(cd,np.s_[0:i],0)
                cdntplot = np.delete(t,np.s_[0:i],0)
            else:
                cdnplot = np.copy(cd)
                cdntplot = np.copy(t)
            kk = 0
            while kk < nv:
                if kk == 0:
                    fig = plt.figure()
                    ax = fig.add_subplot(111)
                plt.plot(cdntplot,cdnplot[:,kk],linewidth=1.0,color='0.6')
                plt.plot(cdnt,cdn[:,kk],'k-',linewidth=1.0)
                kk = kk + 1
            plt.xlabel('$t$ (ms)')
            plt.ylabel('$i$ (mA cm$^{\minus2}$)')
            legend = ['Estimated','Predicted']
            plt.legend(legend, fontsize=10, ncol=1, loc = 'best')
            plt.title('k = '+str(k0)+': Leak-subtracted current densities predicted by the model')
            plt.savefig(outputdir+'/cd.png',dpi=600)
        
        ML = load_matrix(outputdir+'/'+'cdL_'+str(k0)+'.txt'); cdL = ML[0][:,1]
        M,H,S = load_matrix(outputdir+'/'+'cdn_'+str(k0)+'_paras.txt',skip=1)
        s = S[0].split(); fullmodel = s[0]
        paratable = M[:,1:len(M[0])]; V = M[:,0]
        if fullmodel == 'A^k' or fullmodel == 'A^k+L':
            fig, axs = plt.subplots(2, 1, sharex='all')
            axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
            axs[0].plot(V,cdL,'b-o',linewidth=1.0)
            axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
            axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
            axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
            axs[1].set_xlabel('$V$ (mV)')
            axs[1].set_ylabel('${\\tau}m1$ (ms)')
        elif fullmodel == '(A^k)A' or fullmodel == '(A^k)A+L':
            fig, axs = plt.subplots(2, 1, sharex='all')
            axs[0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
            axs[0].plot(V,cdL,'b-o',linewidth=1.0)
            axs[0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
            axs[0].set_ylabel('$i$ (mA cm$^{\minus2}$)')
            axs[1].plot(V,paratable[:,1],'k-o',linewidth=1.0)
            axs[1].plot(V,paratable[:,2],'b-o',linewidth=1.0)
            axs[1].legend(['${\\tau}m1a$','${\\tau}m1b$'], title='ms', fontsize=10)                        
            axs[1].set_xlabel('$V$ (mV)')
            axs[1].set_ylabel('${\\tau}m$ (ms)')
        elif fullmodel == 'A^k+A' or fullmodel == 'A^k+A+L': 
            fig, axs = plt.subplots(2, 2, sharex='all')
            axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
            axs[0,0].plot(V,cdL,'b-o',linewidth=1.0)
            axs[0,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
            axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
            axs[1,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
            axs[1,0].set_xlabel('$V$ (mV)')
            axs[1,1].set_xlabel('$V$ (mV)')
            axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')                
            axs[0,1].legend(['$i2\infty$'],title = 'mA cm$^{\minus2}$')   
            axs[1,0].legend(['${\\tau}m1$'],title = 'ms')                
            axs[1,1].legend(['${\\tau}m2$'],title = 'ms')   
        else:
            fig, axs = plt.subplots(2, 2, sharex='all')
            axs[0,0].plot(V,paratable[:,0],'k-o',linewidth=1.0)
            axs[0,0].plot(V,cdL,'b-o',linewidth=1.0)
            axs[1,0].plot(V,paratable[:,1],'k-o',linewidth=1.0)
            axs[0,1].plot(V,paratable[:,3],'k-o',linewidth=1.0)
            if logtauh == 1:
                axs[1,1].semilogy(V,paratable[:,2],'k-o',linewidth=1.0)
            else:
                axs[1,1].plot(V,paratable[:,2],'k-o',linewidth=1.0)
            axs[1,0].set_xlabel('$V$ (mV)')
            axs[1,1].set_xlabel('$V$ (mV)')
            axs[1,0].legend(['${\\tau}m1$'],title = 'ms')
            axs[0,0].legend(['$i1\infty$','$i$L'],title = 'mA cm$^{\minus2}$')
            if 'II' not in fullmodel:
                axs[0,1].legend(['$h1\infty$'])
                axs[1,1].legend(['${\\tau}h1$'], title = 'ms')
            else:
                axs[0,1].plot(V,paratable[:,5],'b-o',linewidth=1.0)
                axs[0,1].legend(['$h1$','$h2$'], title='$h\infty$', fontsize=10)                        
                if logtauh == 1:
                    axs[1,1].semilogy(V,paratable[:,4],'b-o',linewidth=1.0)
                else:
                    axs[1,1].plot(V,paratable[:,4],'b-o',linewidth=1.0)
                axs[1,1].legend(['$h1$','$h2$'], title='${\\tau}h$ (ms)', fontsize=10)
        fig.suptitle('k = '+str(k0)+': Parameter estimates from fitted i(t,V) curves')
        plt.savefig(outputdir+'/paras.png',dpi=600)
        
        predIp = np.full_like(obsI,0)
        error = np.full_like(obsI,0)
        j = 0
        while j < nv:
            p = intp.interp1d(tp,predI[:,j],fill_value='extrapolate')
            predIp[:,j] = p(obst); i = 0
            while i < n:
                error[i,j] = obsI[i,j] - predIp[i,j]
                i = i + 1
            j = j + 1
        result = {'Best iteration': k0, 'output_folder': outputdir, 'Residuals(pA)': error}
    return result
